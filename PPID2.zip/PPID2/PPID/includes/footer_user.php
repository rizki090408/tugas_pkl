<footer style="background:#2563eb; color:#fff; padding:20px 15px; text-align:center; font-family: 'Inter', sans-serif;">
  <p style="margin:0; font-size:14px;">&copy; <?= date('Y') ?> PPID. All rights reserved.</p>
  <p style="margin:5px 0 0 0; font-size:13px; opacity:0.8;">
    Hubungi kami: <a href="mailto:info@ppid.com" style="color:#93c5fd; text-decoration:none;">info@ppid.com</a> | 
    <a href="tel:+628123456789" style="color:#93c5fd; text-decoration:none;">+62 812-3456-789</a>
  </p>
</footer>
