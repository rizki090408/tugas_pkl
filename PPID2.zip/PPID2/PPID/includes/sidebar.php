<?php
$current = basename($_SERVER['PHP_SELF']);
?>

<!-- Sidebar Container -->
<div class="sidebar" style="display: flex; flex-direction: column; justify-content: space-between; height: 100vh;">

  <!-- Logo + Navigasi -->
  <div>
    <div class="logo" style="text-align: center; padding: 20px;">
      <img src="assets/img/bbpmp.png" alt="Logo BBPMP" class="logo-img" style="width: 60px;">
      <h2 style="margin: 10px 0 0;">BBPMP <br><small>Jabar</small></h2>
    </div>
    <nav>
      <ul style="list-style: none; padding-left: 0;">
        <li><a href="index.php" class="<?= $current == 'index.php' ? 'active' : '' ?>">Home</a></li>
        <li><a href="daftar informasi.php" class="<?= $current == 'daftar informasi.php' ? 'active' : '' ?>">Daftar Informasi</a></li>
        <li><a href="form permohonan.php" class="<?= $current == 'form permohonan.php' ? 'active' : '' ?>">Permohonan</a></li>
        <li><a href="status permohonan.php" class="<?= $current == 'status permohonan.php' ? 'active' : '' ?>">Detail Permohonan</a></li>
        <li><a href="umpan balik.php" class="<?= $current == 'umpan balik.php' ? 'active' : '' ?>">Umpan Balik</a></li>
        <!-- <li><a href="edit_profile.php" class="<?= $current == 'edit_profile.php' ? 'active' : '' ?>">edit profile</a></li>  -->
      </ul>
    </nav>
  </div>

  <!-- Logout di bagian bawah -->
  <!-- <div style="padding: 20px; text-align: center;">
    <a href="auth/logout.php" style="color: white; text-decoration: none;">
      <img src="assets/img/power-on (1).png" alt="Logout" style="width: 50px; vertical-align: middle;">
    </a>
  </div> -->

</div>
