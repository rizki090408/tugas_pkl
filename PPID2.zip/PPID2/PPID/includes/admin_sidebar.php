<!-- admin_sidebar.php -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <img src="../assets/img/bbpmp.png" alt="Logo" class="logo">
        <span class="brand">PPID Admin</span>
        <button id="collapseBtn" class="toggle-btn" title="Sembunyikan Sidebar">
            <i class="fas fa-chevron-left"></i>
        </button>
    </div>
    <nav class="menu">
        <a href="dashboard.php" class="menu-item active">
            <i class="fas fa-home"></i> Dashboard
        </a>
        <a href="detail_permohonan.php" class="menu-item">
            <i class="fas fa-file-alt"></i> Data Permohonan
        </a>
        <a href="umpan_balik.php" class="menu-item">
            <i class="fas fa-comments"></i> Komentar
        </a>
        <a href="../auth/logout.php" class="menu-item logout">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </nav>
</aside>
 
<!-- Tombol floating -->
<button id="openSidebarBtn" class="open-btn" title="Buka Sidebar">
    <i class="fas fa-bars"></i>
</button>

<!-- Font Awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ======== Sidebar ======== */
.sidebar {
    width: 250px;
    height: 100vh;
    background: #ffffffcc;
    backdrop-filter: blur(10px);
    border-right: 1px solid rgba(0,0,0,0.1);
    position: fixed;
    left: 0;
    top: 0;
    display: flex;
    flex-direction: column;
    transition: transform 0.3s ease, width 0.3s ease;
    z-index: 1000;
    box-shadow: 2px 0 15px rgba(0,0,0,0.05);
}

.sidebar.collapsed {
    transform: translateX(-100%);
}

/* ======== Sidebar Header ======== */
.sidebar-header {
    display: flex;
    align-items: center;
    padding: 15px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
}
.logo {
    width: 30px;
    height: 30px;
    margin-right: 10px;
}
.brand {
    font-size: 18px;
    font-weight: bold;
    color: #2563eb;
    flex: 1;
}
.toggle-btn {
    background: none;
    border: none;
    color: #6b7280;
    font-size: 16px;
    cursor: pointer;
}
.toggle-btn:hover {
    color: #2563eb;
}

/* ======== Menu ======== */
.menu {
    flex: 1;
    display: flex;
    flex-direction: column;
}
.menu-item {
    padding: 12px 20px;
    font-size: 14px;
    display: flex;
    align-items: center;
    color: #374151;
    text-decoration: none;
    transition: background 0.25s ease, padding-left 0.25s ease;
}
.menu-item i {
    margin-right: 10px;
}
.menu-item:hover {
    background: rgba(37, 99, 235, 0.08);
    padding-left: 25px;
}
.menu-item.active {
    background: rgba(37, 99, 235, 0.15);
    color: #2563eb;
    font-weight: 600;
}
.menu-item.logout {
    color: #dc2626;
}

/* ======== Floating Button ======== */
.open-btn {
    display: none;
    position: fixed;
    left: 15px;
    top: 15px;
    background: #2563eb;
    color: white;
    border: none;
    padding: 10px 12px;
    border-radius: 8px;
    cursor: pointer;
    z-index: 1100;
    box-shadow: 0 4px 10px rgba(0,0,0,0.15);
}

/* ======== Main Content ======== */
main {
    margin-left: 250px;
    transition: margin-left 0.3s ease;
}

/* Saat sidebar collapse, konten melebar */
main.expanded {
    margin-left: 0;
}

/* ======== Responsive ======== */
@media (max-width: 992px) {
    .sidebar {
        transform: translateX(-100%);
    }
    .sidebar.show {
        transform: translateX(0);
    }
    .open-btn {
        display: block;
    }
    main {
        margin-left: 0; /* di mobile konten full lebar */
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const collapseBtn = document.getElementById('collapseBtn');
    const openSidebarBtn = document.getElementById('openSidebarBtn');
    const mainContent = document.querySelector('main');

    collapseBtn.addEventListener('click', () => {
        sidebar.classList.add('collapsed');
        openSidebarBtn.style.display = 'block';
        mainContent.classList.add('expanded'); // Konten melebar
    });

    openSidebarBtn.addEventListener('click', () => {
        sidebar.classList.remove('collapsed');
        sidebar.classList.add('show');
        openSidebarBtn.style.display = 'none';
        mainContent.classList.remove('expanded'); // Konten normal
    });

    // Tutup sidebar saat klik menu item di mobile
    document.querySelectorAll('.menu-item').forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 992) {
                sidebar.classList.remove('show');
                openSidebarBtn.style.display = 'block';
            }
        });
    });

    // Optional: hilangkan class 'show' saat resize ke desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 992) {
            sidebar.classList.remove('show');
            openSidebarBtn.style.display = 'none';
            mainContent.classList.remove('expanded');
            sidebar.classList.remove('collapsed');
        }
    });
});
</script>
