<?php
session_start();
$isLoggedIn = isset($_SESSION['user']);
$user = $isLoggedIn ? $_SESSION['user'] : null;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>PPID BBPMP Jabar</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
 * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f7f7f9;
      color: #333;
    }
    header {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      background: rgba(255, 255, 255, 0.95);
      border-bottom: 1px solid #eee;
      z-index: 1000;
    }
    .header-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 16px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .logo img { height: 32px; }
    nav ul {
      list-style: none;
      display: flex;
      gap: 24px;
    }
    nav ul li a {
      text-decoration: none;
      color: #222;
      font-weight: 500;
      font-size: 15px;
      transition: color 0.2s ease;
    }
    nav ul li a:hover { color: #00796b; }
    .actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }
    .signin { text-decoration: none; color: #333; font-weight: 500; }
    .btn-demo {
      background: #009688; color: white; text-decoration: none;
      padding: 8px 16px; border-radius: 6px; font-weight: 600;
      transition: background 0.2s ease;
    }
    .btn-demo:hover { background: #00796b; }
    @media (max-width: 768px) {
      nav ul { display: none; }
      .actions { gap: 8px; }
    }
    /* Profile menu */
    .profile-menu { position: relative; display: inline-block; }
    .profile-menu img {
        width: 38px; height: 38px; border-radius: 50%;
        cursor: pointer; object-fit: cover;
    }
    .dropdown {
        display: none; position: absolute; right: 0;
        background: white; border: 1px solid #ddd;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        border-radius: 6px; min-width: 150px; z-index: 999;
    }
    .dropdown a {
        display: block; padding: 10px; color: #333;
        text-decoration: none;
    }
    .dropdown a:hover { background: #f0f0f0; }
    .profile-menu:hover .dropdown { display: block; }
</style>
</head>
<body>
<header>
  <div class="header-container">
    <div class="logo">
      <img src="assets/img/bbpmptext.png" alt="Logo">
    </div>
    <nav>
      <ul>
        <li><a href="index.php">Dashboard</a></li>
        <li><a href="daftar informasi.php">Informasi</a></li>
        <?php if ($isLoggedIn): ?>
          <li><a href="form permohonan.php">Permohonan</a></li>
          <li><a href="status permohonan.php">History</a></li>
          <li><a href="umpan balik.php">Umpan Balik</a></li>
        <?php endif; ?>
      </ul>
    </nav>
    <div class="actions">
      <?php if (!$isLoggedIn): ?>
        <a href="auth/register.php" class="signin">Daftar</a>
        <a href="auth/login.php" class="btn-demo">Login</a>
      <?php else: ?>
        <div class="profile-menu">
          <?php
            if (!empty($user['foto'])) {
                $fotoSrc = "data:image/jpeg;base64," . base64_encode($user['foto']);
            } else {
                $fotoSrc = "assets/img/profile-picture.png"; // fallback foto default
            }
          ?>
          <img src="<?= $fotoSrc ?>" alt="Foto Profil">
          <div class="dropdown">
            <a href="detail_profile.php">Detail Profil</a>
            <a href="auth/logout.php">Logout</a>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</header>
