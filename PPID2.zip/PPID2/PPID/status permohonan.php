<?php
session_start();
include 'includes/header.php';
include 'includes/koneksi.php';

// Cek login
if (!isset($_SESSION['user'])) {
    header("Location: auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id']; // Ambil ID user dari session array

// Ambil data dari database hanya untuk user ini
$query = "SELECT * FROM permohonan WHERE user_id = '$user_id' ORDER BY tanggal DESC";
$result = mysqli_query($koneksi, $query);
?>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
    font-family: 'Inter', sans-serif;
    background: #f4f6f9;
    margin: 0;
    padding: 0;
  }

  .main-content {
    margin-top: 100px;
    max-width: 1100px;
    margin-left: auto;
    margin-right: auto;
    background: #ffffff;
    border-radius: 12px;
    padding: 30px 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  }

  h2 {
    margin-bottom: 24px;
    color: #333;
    font-size: 24px;
  }

  .tabel-status {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
  }

  .tabel-status thead {
    background-color: #009688;
    color: #fff;
  }

  .tabel-status th,
  .tabel-status td {
    padding: 12px 16px;
    text-align: left;
    border-bottom: 1px solid #e0e0e0;
    font-size: 14px;
  }

  .tabel-status tbody tr:hover {
    background-color: #f1f1f1;
  }

  .tabel-status a {
    color: #007bff;
    text-decoration: none;
    font-weight: 500;
  }

  .tabel-status a:hover {
    text-decoration: underline;
  }

  @media(max-width: 768px) {
    .tabel-status thead {
      display: none;
    }

    .tabel-status, .tabel-status tbody, .tabel-status tr, .tabel-status td {
      display: block;
      width: 100%;
    }

    .tabel-status tr {
      margin-bottom: 15px;
      border: 1px solid #ddd;
      border-radius: 6px;
      padding: 10px;
      background-color: #fff;
    }

    .tabel-status td {
      text-align: right;
      padding-left: 50%;
      position: relative;
    }

    .tabel-status td::before {
      content: attr(data-label);
      position: absolute;
      left: 16px;
      width: 45%;
      padding-right: 10px;
      white-space: nowrap;
      font-weight: bold;
      color: #555;
      text-align: left;
    }
  }
</style>

<div class="main-content">
  <h2>Riwayat Permohonan</h2>

  <table class="tabel-status">
    <thead>
      <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Informasi</th>
        <th>Tanggal</th>
        <th>Dokumen</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      while ($data = mysqli_fetch_assoc($result)) {
        echo "<tr>
          <td data-label='No'>{$no}</td>
          <td data-label='Nama'>{$data['nama']}</td>
          <td data-label='Informasi'>{$data['informasi']}</td>
          <td data-label='Tanggal'>" . date('d/m/Y', strtotime($data['tanggal'])) . "</td>
          <td data-label='Dokumen'>";
        if ($data['dokumen']) {
          echo "<a href='upload/{$data['dokumen']}' target='_blank'>Lihat</a>";
        } else {
          echo "-";
        }
        echo "</td>
          <td data-label='Aksi'>
            <a href='hapus_permohonan.php?id={$data['id']}' onclick='return confirm(\"Yakin hapus?\")'>🗑️</a>
          </td>
        </tr>";
        $no++;
      }
      ?>
    </tbody>
  </table>
</div>
