<?php
session_start();
include 'includes/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: auth/login.php");
    exit();
}

$username = $_SESSION['username'];
$error = "";
$success = "";

$query = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$username'");
$user = mysqli_fetch_assoc($query);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old_password = trim($_POST['old_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
        $error = "Semua kolom wajib diisi.";
    } elseif (!password_verify($old_password, $user['password'])) {
        $error = "Password lama salah.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Konfirmasi password tidak cocok.";
    } else {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $sql = "UPDATE user SET password='$hashed' WHERE username='$username'";
        if (mysqli_query($koneksi, $sql)) {
            $success = "Password berhasil diperbarui.";
        } else {
            $error = "Gagal mengubah password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Ubah Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
    .container { max-width: 500px; margin-top: 80px; }
    .card { border-radius: 10px; box-shadow: 0 6px 18px rgba(0,0,0,0.1); }
    .btn-primary { background-color: #1a32b6; border: none; }
    .btn-primary:hover { background-color: #142194; }
  </style>
</head>
<body>
<div class="container">
  <div class="card p-4">
    <h4 class="mb-3">Ubah Password</h4>

    <?php if ($success): ?>
      <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php elseif ($error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Password Lama</label>
        <input type="password" name="old_password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password Baru</label>
        <input type="password" name="new_password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Konfirmasi Password Baru</label>
        <input type="password" name="confirm_password" class="form-control" required>
      </div>
      <div class="d-flex justify-content-between">
        <a href="edit_profile.php" class="btn btn-secondary">← Kembali</a>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
</body>
</html>
