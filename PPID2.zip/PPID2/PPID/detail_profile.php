<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: auth/login.php");
    exit();
}

require 'includes/koneksi.php';

// Pastikan kita punya ID user
if (is_array($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $userId = (int) $_SESSION['user']['id'];
} else {
    $nama = $_SESSION['user'];
    $stmt = $koneksi->prepare("SELECT id FROM user WHERE nama = ?");
    $stmt->bind_param("s", $nama);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    if (!$row) {
        echo "User tidak ditemukan.";
        exit();
    }
    $userId = (int) $row['id'];
}

// Ambil data user
$stmt = $koneksi->prepare("SELECT id, nama, email, nik, no_hp, alamat, foto FROM user WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "Data pengguna tidak ditemukan.";
    exit();
}

$_SESSION['user'] = $user;

// Cek sumber foto
if (!empty($user['foto'])) {
    if (file_exists("upload/" . $user['foto'])) {
        $fotoSrc = "upload/" . $user['foto'];
    } else {
        $fotoSrc = "data:image/jpeg;base64," . base64_encode($user['foto']);
    }
} else {
    $fotoSrc = "assets/img/default-profile.png";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Detail Profil</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
    body {
        font-family: 'Segoe UI', Arial, sans-serif;
        background: linear-gradient(135deg, #eceff1, #f5f6fa);
        margin: 0;
        padding: 20px;
    }
    .profile-container {
        max-width: 500px;
        margin: auto;
        background: white;
        border-radius: 15px;
        box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        overflow: hidden;
        animation: fadeIn 0.5s ease-in-out;
    }
    .profile-header {
        background: linear-gradient(90deg, #3f51b5, #5c6bc0);
        padding: 40px 20px 30px;
        text-align: center;
        color: white;
        position: relative;
    }
    .profile-header img {
        width: 130px;
        height: 130px;
        border-radius: 50%;
        border: 4px solid white;
        object-fit: cover;
        background: white;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }
    .profile-header h2 {
        margin: 15px 0 5px;
        font-size: 1.8rem;
        font-weight: bold;
    }
    .profile-header p {
        font-size: 1rem;
        opacity: 0.9;
    }
    .profile-body {
        padding: 25px;
    }
    .profile-info {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    .profile-info li {
        display: flex;
        justify-content: space-between;
        padding: 12px 0;
        border-bottom: 1px solid #f0f0f0;
        font-size: 0.95rem;
    }
    .profile-info li strong {
        color: #555;
    }
    .profile-actions {
        padding: 20px;
        text-align: center;
        background: #fafafa;
        border-top: 1px solid #f0f0f0;
    }
    .btn {
    display: inline-block;
    padding: 12px 20px;
    margin: 5px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
    transition: all 0.2s ease;
    border: none;
    cursor: pointer;
    font-size: 0.95rem;
    min-width: 140px; /* lebar seragam */
    text-align: center; /* teks di tengah */
    width: 100px;
    height: auto;
    }
    .btn-primary {
        background: #3f51b5;
        color: white;
    }
    .btn-primary:hover {
        background: #283593;
    }
    .btn-secondary {
        background: #9e9e9e;
        color: white;
    }
    .btn-secondary:hover {
        background: #757575;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
</head>
<body>

<div class="profile-container">
    <div class="profile-header">
        <img src="<?= htmlspecialchars($fotoSrc) ?>" alt="Foto Profil">
        <h2><?= htmlspecialchars($user['nama']) ?></h2>
        <p><?= htmlspecialchars($user['email']) ?></p>
    </div>
    <div class="profile-body">
        <ul class="profile-info">
            <li><strong>NIK</strong> <span><?= htmlspecialchars($user['nik'] ?? '-') ?></span></li>
            <li><strong>No HP</strong> <span><?= htmlspecialchars($user['no_hp'] ?? '-') ?></span></li>
            <li><strong>Alamat</strong> <span><?= htmlspecialchars($user['alamat'] ?? '-') ?></span></li>
        </ul>
    </div>
    <div class="profile-actions">
        <a href="edit_profile.php" class="btn btn-primary">Edit</a>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </div>
</div>
</body>
</html>
