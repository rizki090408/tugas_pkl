<?php
session_start();
include 'includes/koneksi.php';

if (!isset($_SESSION['user'])) {
    header("Location: auth/login.php");
    exit();
}

$user = $_SESSION['user'];

// Ambil data lama
$result = $koneksi->query("SELECT foto FROM user WHERE id=" . intval($user['id']));
$data = $result->fetch_assoc();

// Hapus file fisik jika ada
if (!empty($data['foto']) && file_exists("upload/" . $data['foto'])) {
    unlink("upload/" . $data['foto']);
}

// Set kolom foto menjadi NULL
$stmt = $koneksi->prepare("UPDATE user SET foto=NULL WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();

// Update session
$result = $koneksi->query("SELECT * FROM user WHERE id=" . intval($user['id']));
$_SESSION['user'] = $result->fetch_assoc();

header("Location: detail_profile.php");
exit();
