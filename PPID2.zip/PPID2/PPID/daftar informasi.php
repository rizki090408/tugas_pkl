<?php
include 'includes/header.php';
include 'includes/koneksi.php';

$filter = $_GET['filter'] ?? 'semua';

switch ($filter) {
  case 'terdekat':
    $query = "SELECT * FROM informasi ORDER BY tanggal DESC LIMIT 6";
    break;
  case 'sering':
    $query = "SELECT * FROM informasi ORDER BY jumlah_view DESC LIMIT 6";
    break;
  default:
    $query = "SELECT * FROM informasi ORDER BY id DESC";
}

$result = mysqli_query($koneksi, $query);
?>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Inter', sans-serif;
    background: #f5f6f8;
    margin: 0;
    padding: 0;
  }

  .main-content {
    margin-top: 100px;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    padding: 40px 20px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  }

  h2 {
    margin-bottom: 24px;
    color: #333;
  }

  .filter-buttons {
    margin-bottom: 30px;
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
  }

  .filter-buttons .btn {
    padding: 8px 16px;
    text-decoration: none;
    color: #555;
    background: #e0e0e0;
    border-radius: 6px;
    font-weight: 500;
    transition: background 0.2s ease, color 0.2s ease;
  }

  .filter-buttons .btn.active,
  .filter-buttons .btn:hover {
    background: #009688;
    color: #fff;
  }

  .image-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 20px;
  }

  .info-card {
    background: #fff;
    border: 1px solid #eee;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
  }

  .info-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.08);
  }

  .info-img {
    width: 100%;
    height: 160px;
    object-fit: cover;
  }

  .info-content {
    padding: 16px;
    flex: 1;
    display: flex;
    flex-direction: column;
  }

  .info-content h4 {
    margin: 0 0 8px;
    color: #00796b;
    font-size: 18px;
  }

  .deskripsi {
    color: #555;
    margin-bottom: 12px;
    font-size: 14px;
    flex: 1;
  }

  .tanggal {
    font-size: 13px;
    color: #777;
  }

  .btn-detail {
    display: inline-block;
    margin-top: 12px;
    padding: 8px 12px;
    background: #009688;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    font-weight: 500;
    transition: background 0.2s ease;
  }

  .btn-detail:hover {
    background: #00796b;
  }
</style>

<div class="main-content">
  <h2>Daftar Informasi</h2>

  <!-- Filter Buttons -->
  <div class="filter-buttons">
    <a href="?filter=semua" class="btn <?= ($filter == 'semua') ? 'active' : '' ?>">Semua</a>
    <a href="?filter=terdekat" class="btn <?= ($filter == 'terdekat') ? 'active' : '' ?>">Terdekat</a>
    <a href="?filter=sering" class="btn <?= ($filter == 'sering') ? 'active' : '' ?>">Sering Dilihat</a>
  </div>

  <!-- Grid Card Layout -->
  <div class="image-grid">
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
      <div class="info-card">
        <img src="upload/<?= $row['gambar'] ?>" alt="<?= htmlspecialchars($row['judul']) ?>" class="info-img">
        <div class="info-content">
          <h4><?= htmlspecialchars($row['judul']) ?></h4>
          <p class="deskripsi"><?= htmlspecialchars(substr($row['deskripsi'], 0, 80)) ?>...</p>
          <small class="tanggal"><strong>Tanggal:</strong> <?= date('d M Y', strtotime($row['tanggal'])) ?></small>
          <small><br><strong>View:</strong> <?= $row['jumlah_view'] ?> kali</small>
          <a href="detail informasi.php?id=<?= $row['id'] ?>" class="btn-detail">Lihat Detail</a>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>
