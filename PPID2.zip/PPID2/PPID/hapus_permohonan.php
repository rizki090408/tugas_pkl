<?php
session_start();
include 'includes/koneksi.php';

// Cek login
if (!isset($_SESSION['user'])) {
    header("Location: auth/login.php");
    exit();
}

// Ambil ID dari URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    die("ID permohonan tidak valid.");
}

// Ambil dokumen terkait
$stmt = $koneksi->prepare("SELECT dokumen FROM permohonan WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();

// Hapus file jika ada
if ($data && !empty($data['dokumen'])) {
    $file_path = 'upload/' . $data['dokumen'];
    if (file_exists($file_path)) {
        unlink($file_path);
    }
}

// Hapus data di database
$stmt = $koneksi->prepare("DELETE FROM permohonan WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: status permohonan.php");
    exit();
} else {
    echo "Gagal menghapus permohonan: " . $stmt->error;
}
?>
