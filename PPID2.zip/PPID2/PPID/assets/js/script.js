document.addEventListener("DOMContentLoaded", function () {
  console.log("PPID Digital ready.");
});


// Slider
function scrollSlider(amount) {
  const slider = document.getElementById("slider");
  slider.scrollBy({ left: amount, behavior: "smooth" });
}

const slider = document.getElementById("slider");
const dotsContainer = document.getElementById("slider-dots");
const items = slider.querySelectorAll(".slider-item");
const visibleItems = 3;
const totalSlides = Math.ceil(items.length / visibleItems);
let currentSlide = 0;

for (let i = 0; i < totalSlides; i++) {
  const dot = document.createElement("div");
  dot.classList.add("dot");
  if (i === 0) dot.classList.add("active");
  dot.addEventListener("click", () => {
    currentSlide = i;
    scrollToSlide(i);
  });
  dotsContainer.appendChild(dot);
}

function scrollToSlide(index) {
  const itemWidth = items[0].offsetWidth + 20; // 20 = gap antar item
  slider.scrollTo({
    left: index * itemWidth * visibleItems,
    behavior: "smooth",
  });
  updateDots(index);
}

function updateDots(index) {
  const dots = dotsContainer.querySelectorAll(".dot");
  dots.forEach((dot) => dot.classList.remove("active"));
  if (dots[index]) dots[index].classList.add("active");
}

slider.addEventListener("mouseenter", () => clearInterval(autoScrollInterval));
slider.addEventListener("mouseleave", () => {
  autoScrollInterval = setInterval(() => {
    currentSlide = (currentSlide + 1) % totalSlides;
    scrollToSlide(currentSlide);
  }, 5000);
});


// Star
document.addEventListener('DOMContentLoaded', function () {
  const stars = document.querySelectorAll('.star');
  const ratingInput = document.getElementById('rating');

  function resetClasses() {
    stars.forEach(star => {
      star.className = 'star'; // reset all class
    });
  }

  stars.forEach(star => {
    star.addEventListener('click', function () {
      const value = parseInt(this.getAttribute('data-value'));
      ratingInput.value = value;
      resetClasses();
      for (let i = 0; i < value; i++) {
        stars[i].classList.add(`selected-${value}`);
      }
    });

    star.addEventListener('mouseover', function () {
      const value = parseInt(this.getAttribute('data-value'));
      resetClasses();
      for (let i = 0; i < value; i++) {
        stars[i].classList.add(`hover-${value}`);
      }
    });

    star.addEventListener('mouseout', function () {
      const currentValue = parseInt(ratingInput.value);
      resetClasses();
      if (currentValue) {
        for (let i = 0; i < currentValue; i++) {
          stars[i].classList.add(`selected-${currentValue}`);
        }
      }
    });
  });
});
