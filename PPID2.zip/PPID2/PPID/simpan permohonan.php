<?php
session_start();
include 'includes/koneksi.php';

// Cek login
if (!isset($_SESSION['user'])) {
    header("Location: auth/login.php");
    exit;
}

$user_id = $_SESSION['user']['id']; // Ambil ID user dari session array

// Escape input
$nama            = mysqli_real_escape_string($koneksi, $_POST['nama']);
$jenis_kelamin   = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
$no_hp           = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
$ktp             = mysqli_real_escape_string($koneksi, $_POST['ktp']);
$email           = mysqli_real_escape_string($koneksi, $_POST['email']);
$pekerjaan       = mysqli_real_escape_string($koneksi, $_POST['pekerjaan']);
$unit_kerja      = mysqli_real_escape_string($koneksi, $_POST['unit_kerja']);
$alamat          = mysqli_real_escape_string($koneksi, $_POST['alamat']);
$kabkota         = mysqli_real_escape_string($koneksi, $_POST['kabkota']);
$provinsi        = mysqli_real_escape_string($koneksi, $_POST['provinsi']);
$kategori        = mysqli_real_escape_string($koneksi, $_POST['kategori']);
$fasilitas       = mysqli_real_escape_string($koneksi, $_POST['fasilitas']);
$informasi       = mysqli_real_escape_string($koneksi, $_POST['informasi']);

// Tambahan field baru
$tujuan          = mysqli_real_escape_string($koneksi, $_POST['tujuan']);
$cara_memperoleh = mysqli_real_escape_string($koneksi, $_POST['cara_memperoleh']);
$cara_salinan    = mysqli_real_escape_string($koneksi, $_POST['cara_salinan']);

// Upload dokumen
$dokumen = "";
if (isset($_FILES['dokumen']) && $_FILES['dokumen']['error'] == 0) {
    $dokumen = time() . "_" . basename($_FILES['dokumen']['name']);
    move_uploaded_file($_FILES['dokumen']['tmp_name'], "upload/" . $dokumen);
}

// Simpan ke database (pakai kolom user_id, bukan id)
$query = "INSERT INTO permohonan 
(user_id, nama, jenis_kelamin, no_hp, ktp, email, pekerjaan, unit_kerja, alamat, kabkota, provinsi, kategori, fasilitas, informasi, tujuan, cara_memperoleh, cara_salinan, tanggal, dokumen)
VALUES 
('$user_id', '$nama', '$jenis_kelamin', '$no_hp', '$ktp', '$email', '$pekerjaan', '$unit_kerja', '$alamat', '$kabkota', '$provinsi', '$kategori', '$fasilitas', '$informasi', '$tujuan', '$cara_memperoleh', '$cara_salinan', NOW(), '$dokumen')";

if (mysqli_query($koneksi, $query)) {
    header("Location: status permohonan.php");
} else {
    echo "Error: " . mysqli_error($koneksi);
}
?>
