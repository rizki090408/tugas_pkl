<?php
  include 'includes/header.php';
  include 'includes/koneksi.php';

  $permohonan = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM permohonan"));
  $umpan_balik = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM umpan_balik"));
  $total_data = $permohonan + $umpan_balik;

  $info_query = mysqli_query($koneksi, "SELECT * FROM informasi WHERE tanggal <= CURDATE() ORDER BY tanggal DESC LIMIT 5");
?>

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Inter', sans-serif;
    background: #f8f9fa;
    margin: 0;
    padding: 0;
  }

  .main-content {
    margin-top: 100px; /* jarak untuk header fixed */
    padding: 40px 20px;
    max-width: 1200px;
    margin-left: auto;
    margin-right: auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  }

  h2 {
    font-size: 28px;
    color: #333;
  }

  .welcome-text {
    font-size: 16px;
    margin-bottom: 30px;
    color: #555;
  }

  .info-boxes {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-bottom: 40px;
  }

  .info-card {
    flex: 1;
    min-width: 180px;
    background: #eee;
    color: #fff;
    border-radius: 12px;
    padding: 24px;
    text-align: center;
    transition: transform 0.2s ease, box-shadow 0.3s ease;
  }

  .info-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
  }

  .card-blue {
    background: linear-gradient(135deg, #4a90e2, #007aff);
  }

  .card-green {
    background: linear-gradient(135deg, #34c759, #30d158);
  }

  .card-purple {
    background: linear-gradient(135deg, #8e44ad, #9b59b6);
  }

  .slider-wrapper {
    position: relative;
    overflow: hidden;
    margin-top: 20px;
  }

  .info-slider {
    display: flex;
    overflow-x: auto;
    scroll-behavior: smooth;
    gap: 20px;
    padding: 10px 0;
  }

  .slider-item {
    flex: 0 0 auto;
    width: 200px;
    background: #fff;
    border: 1px solid #eee;
    border-radius: 10px;
    padding: 10px;
    text-align: center;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05);
  }

  .slider-item img {
    width: 100%;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 10px;
  }

  .slider-btn {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: #007aff;
    color: #fff;
    border: none;
    border-radius: 50%;
    width: 36px;
    height: 36px;
    cursor: pointer;
    z-index: 10;
    font-size: 20px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
  }

  .slider-btn:hover {
    background: #005fcc2a;
  }

  .slider-btn:first-of-type {
    left: -10px;
  }

  .slider-btn:last-of-type {
    right: -10px;
  }

  /* RESPONSIF MOBILE */
  @media (max-width: 768px) {
    .info-boxes {
      flex-direction: column;
    }
    .info-card {
      min-width: 100%;
    }
    .slider-item {
      width: 160px;
    }
  }
</style>

<div class="main-content">
  <h2>Dashboard PPID</h2>
  <p class="welcome-text">Selamat datang di <strong>PPID - BBPMP Jabar</strong></p>

  <!-- Info Box -->
  <div class="info-boxes">
    <div class="info-card card-blue">
      <h3><?= $permohonan ?></h3>
      <p>Permohonan Masuk</p>
    </div>
    <div class="info-card card-green">
      <h3><?= $umpan_balik ?></h3>
      <p>Umpan Balik</p>
    </div>
    <div class="info-card card-purple">
      <h3><?= $total_data ?></h3>
      <p>Total Data</p>
    </div>
  </div>

  <!-- Informasi Terbaru -->
  <h3>Informasi Terbaru</h3>
  <div class="slider-wrapper">
    <button class="slider-btn" onclick="scrollSlider(-200)">‹</button>
    <div class="info-slider" id="slider">
      <?php while($row = mysqli_fetch_assoc($info_query)): ?>
        <div class="slider-item">
          <img src="upload/<?= $row['gambar'] ?>" alt="<?= $row['judul'] ?>">
          <p><strong><?= $row['judul'] ?></strong></p>
        </div>
      <?php endwhile; ?>
    </div>
    <button class="slider-btn" onclick="scrollSlider(200)">›</button>
  </div>
</div>

<script>
  function scrollSlider(distance) {
    document.getElementById('slider').scrollBy({
      left: distance,
      behavior: 'smooth'
    });
  }
</script>

</body>
</html>
