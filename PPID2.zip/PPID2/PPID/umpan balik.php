<?php
include 'includes/header.php';
include 'includes/koneksi.php';

$pesan = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $nama = $_POST['nama'];
  $komentar = $_POST['komentar'];
  $rating = $_POST['rating'];

  $sql = "INSERT INTO umpan_balik (nama, komentar, rating) VALUES ('$nama', '$komentar', $rating)";
  if (mysqli_query($koneksi, $sql)) {
    $pesan = "Umpan balik berhasil dikirim!";
  }
}
?>


<style>
  .main-content {
    margin-top: 100px;
    max-width: 900px;
    margin-left: auto;
    margin-right: auto;
    background: #ffffff;
    border-radius: 12px;
    padding: 30px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    font-family: 'Segoe UI', sans-serif;
  }

  h2, h3 {
    color: #333;
    margin-bottom: 20px;
  }

  .alert-sukses {
    background-color: #d4edda;
    color: #155724;
    padding: 12px 20px;
    border-left: 4px solid #28a745;
    border-radius: 6px;
    margin-bottom: 20px;
  }

  .form-permohonan label {
    display: block;
    margin-bottom: 6px;
    font-weight: 600;
  }

  .form-permohonan input[type="text"],
  .form-permohonan textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    margin-bottom: 16px;
    font-size: 14px;
  }

  .form-permohonan textarea {
    resize: vertical;
    min-height: 100px;
  }

  .rating-group {
    display: flex;
    gap: 8px;
    margin-bottom: 20px;
  }

  .rating-group input[type="radio"] {
    display: none;
  }

  .star-icon {
    font-size: 24px;
    cursor: pointer;
    color: #ccc;
    transition: color 0.2s ease;
  }

  .rating-group input[type="radio"]:checked ~ .star-icon,
  .rating-group input[type="radio"]:checked + .star-icon {
    color: #ffc107;
  }

  .btn-submit {
    background-color: #009688;
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
  }

  .btn-submit:hover {
    background-color: #00796b;
  }

  .feedback-list {
    margin-top: 30px;
  }

  .feedback-card {
    border-bottom: 1px solid #e0e0e0;
    padding: 15px 0;
  }

  .feedback-card strong {
    font-size: 16px;
    color: #333;
  }

  .feedback-card .star-icon {
    color: #ffc107;
    font-size: 18px;
    margin-left: 5px;
  }

  .feedback-card p {
    margin: 8px 0;
    font-size: 14px;
    color: #555;
  }

  .feedback-card small {
    color: #888;
    font-size: 12px;
  }

  @media(max-width: 768px) {
    .main-content {
      padding: 20px;
    }

    .star-icon {
      font-size: 20px;
    }

    .btn-submit {
      width: 100%;
    }
  }
</style>

<div class="main-content">
  <h2>Umpan Balik</h2>

  <?php if ($pesan): ?>
    <div class="alert-sukses"><?= $pesan ?></div>
  <?php endif; ?>

  <form method="POST" class="form-permohonan">
    <label>Nama</label>
    <input type="text" name="nama" required>

    <label>Komentar</label>
    <textarea name="komentar" required></textarea>

    <label>Rating</label>
    <div class="rating-group">
      <?php for ($i = 1; $i <= 5; $i++): ?>
        <label>
          <input type="radio" name="rating" value="<?= $i ?>" required>
          <span class="star-icon">★</span>
        </label>
      <?php endfor; ?>
    </div>

    <button type="submit" class="btn-submit">Kirim Umpan Balik</button>
  </form>

  <hr>

  <h3>Ulasan Terbaru</h3>
  <div class="feedback-list">
    <?php
    $result = mysqli_query($koneksi, "SELECT * FROM umpan_balik ORDER BY tanggal DESC LIMIT 5");
    while ($data = mysqli_fetch_assoc($result)) {
      $rating = (int)$data['rating'];
      echo "<div class='feedback-card'>
              <strong>{$data['nama']}</strong>";
      for ($i = 1; $i <= $rating; $i++) {
        echo "<span class='star-icon'>★</span>";
      }
      echo "<p>{$data['komentar']}</p>
            <small>" . date('d/m/Y', strtotime($data['tanggal'])) . "</small>
            </div>";
    }
    ?>
  </div>
</div>
