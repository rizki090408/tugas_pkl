<?php
include 'includes/koneksi.php';
include 'includes/header.php';

// Ambil ID dari URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id <= 0) {
    echo "<div class='main-content'><p>Informasi tidak valid.</p></div>";
    exit;
}

// Tambah jumlah view
mysqli_query($koneksi, "UPDATE informasi SET jumlah_view = jumlah_view + 1 WHERE id = $id");

// Ambil data
$stmt = mysqli_prepare($koneksi, "SELECT * FROM informasi WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<div class='main-content'><p>Informasi tidak ditemukan.</p></div>";
    exit;
}
?>

<style>
/* Reset & font */
body {
  font-family: 'Segoe UI', sans-serif;
  background-color: #f4f6f8;
  margin: 0;
}

/* Wrapper */
.detail-container {
  margin-top: 100px; /* Jarak dari header */
}

/* Hero section */
.hero-image {
  position: relative;
  width: 100%;
  height: 420px;
  background: url('upload/<?= htmlspecialchars($data['gambar']) ?>') center/cover no-repeat;
  border-radius: 12px;
  overflow: hidden;
  max-width: 1100px;
  margin: 0 auto;
  box-shadow: 0 6px 20px rgba(0,0,0,0.15);
}

.hero-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  padding: 15px 20px;
  background: linear-gradient(to top, rgba(0,0,0,0.6), rgba(0,0,0,0));
  color: #fff;
  display: flex;
  justify-content: space-between;
  font-size: 14px;
}

/* Judul */
.detail-content {
  max-width: 750px;
  margin: 40px auto;
  background: #fff;
  padding: 30px 40px;
  border-radius: 12px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.05);
}

.detail-content h1 {
  font-size: 32px;
  color: #1a237e;
  margin-bottom: 20px;
  line-height: 1.3;
}

/* Deskripsi */
.detail-content p {
  line-height: 1.8;
  color: #444;
  font-size: 17px;
  margin-bottom: 20px;
}

/* Tombol kembali */
.btn-back {
  display: inline-block;
  margin-top: 25px;
  background-color: #1a237e;
  color: white;
  padding: 12px 24px;
  border-radius: 8px;
  text-decoration: none;
  font-weight: 600;
  transition: all 0.3s ease;
}
.btn-back:hover {
  background-color: #0d1335;
  transform: translateY(-2px);
}

/* Responsif */
@media (max-width: 768px) {
  .hero-image {
    height: 280px;
  }
  .detail-content {
    padding: 20px;
  }
  .detail-content h1 {
    font-size: 24px;
  }
}
</style>

<div class="detail-container">
  <!-- Hero Image -->
  <div class="hero-image">
    <div class="hero-overlay">
      <span>📅 <?= date('d M Y', strtotime($data['tanggal'])) ?></span>
      <span>👁 <?= $data['jumlah_view'] ?> kali dilihat</span>
    </div>
  </div>

  <!-- Konten -->
  <div class="detail-content">
    <h1><?= htmlspecialchars($data['judul']) ?></h1>
    <p><?= nl2br(htmlspecialchars($data['deskripsi'])) ?></p>
    <a href="daftar informasi.php" class="btn-back">← Kembali ke Daftar</a>
  </div>
</div>

</body>
</html>
