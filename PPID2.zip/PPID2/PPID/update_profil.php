<?php
session_start();
include 'includes/koneksi.php';

if (!isset($_SESSION['username'])) {
    header("Location: auth/login.php");
    exit();
}

$username = $_SESSION['username'];
$error = "";
$success = "";

$query = mysqli_query($koneksi, "SELECT * FROM user WHERE username = '$username'");
$user = mysqli_fetch_assoc($query);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama']);
    $email    = trim($_POST['email']);
    $no_hp    = trim($_POST['no_hp'] ?? '');
    $alamat   = trim($_POST['alamat'] ?? '');
    $foto_blob = null;

    $old_password     = trim($_POST['old_password']);
    $new_password     = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Validasi dasar
    if (empty($nama) || empty($email)) {
        $error = "Nama dan email wajib diisi!";
    } else {
        // Password update
        $update_password = false;
        if (!empty($old_password) || !empty($new_password) || !empty($confirm_password)) {
            if (password_verify($old_password, $user['password'])) {
                if ($new_password === $confirm_password && !empty($new_password)) {
                    $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_password = true;
                } else {
                    $error = "Password baru tidak cocok atau kosong.";
                }
            } else {
                $error = "Password lama salah.";
            }
        }

        // Upload foto jika ada
        if ($_FILES['foto']['size'] > 0 && empty($error)) {
            $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png'];
            if (in_array($ext, $allowed)) {
                $foto_blob = mysqli_real_escape_string($koneksi, file_get_contents($_FILES['foto']['tmp_name']));
            } else {
                $error = "Hanya file JPG, JPEG, dan PNG yang diperbolehkan.";
            }
        }

        // Proses update jika tidak ada error
        if (empty($error)) {
            $sql = "UPDATE user SET 
                        nama='$nama',
                        email='$email',
                        no_hp='$no_hp',
                        alamat='$alamat'";

            if ($update_password) {
                $sql .= ", password='$hashed'";
            }

            if ($foto_blob !== null) {
                $sql .= ", foto='$foto_blob'";
            }

            $sql .= " WHERE username='$username'";

            if (mysqli_query($koneksi, $sql)) {
                $success = "Profil berhasil diperbarui.";
            } else {
                $error = "Gagal memperbarui profil.";
            }
        }
    }
}

$_SESSION['profil_success'] = $success;
$_SESSION['profil_error']   = $error;
header("Location: edit_profile.php");
exit();
?>
