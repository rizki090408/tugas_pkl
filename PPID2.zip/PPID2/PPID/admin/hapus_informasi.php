<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/koneksi.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil nama file gambar
$query = mysqli_query($koneksi, "SELECT gambar FROM informasi WHERE id = $id");
$data = mysqli_fetch_assoc($query);

if ($data && !empty($data['gambar'])) {
    $file_path = '../upload/' . $data['gambar'];
    if (file_exists($file_path)) {
        unlink($file_path);
    }
}

// Hapus data dari database
mysqli_query($koneksi, "DELETE FROM informasi WHERE id = $id");

header("Location: beranda_admin.php");
?>
