<?php
session_start();
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
include '../includes/koneksi.php';
include '../includes/admin_sidebar.php';

/* ====== DATA ====== */
$counts = ['total'=>0,'menunggu'=>0,'sedang'=>0,'selesai'=>0,'ditolak'=>0];
$qTotal = $koneksi->query("SELECT COUNT(*) AS c FROM permohonan");
$counts['total'] = (int) ($qTotal->fetch_assoc()['c'] ?? 0);

$q = $koneksi->query("SELECT status, COUNT(*) AS c FROM permohonan GROUP BY status");
while ($r = $q->fetch_assoc()) {
    $s = strtolower(trim($r['status'] ?? '')); $c = (int) ($r['c'] ?? 0);
    if ($s === 'menunggu') $counts['menunggu'] = $c;
    elseif ($s === 'sedang diproses') $counts['sedang'] = $c;
    elseif ($s === 'selesai') $counts['selesai'] = $c;
    elseif ($s === 'ditolak') $counts['ditolak'] = $c;
}

$monthlyData = array_fill(1, 12, 0);
$qMonth = $koneksi->query("SELECT MONTH(tanggal) as bulan, COUNT(*) as jumlah FROM permohonan GROUP BY MONTH(tanggal)");
while ($row = $qMonth->fetch_assoc()) { $monthlyData[(int)$row['bulan']] = (int)$row['jumlah']; }

$ratingCounts = [1=>0,2=>0,3=>0,4=>0,5=>0];
$qRating = $koneksi->query("SELECT rating, COUNT(*) AS jumlah FROM umpan_balik GROUP BY rating");
while ($row = $qRating->fetch_assoc()) { $r = (int)$row['rating']; if ($r>=1 && $r<=5) $ratingCounts[$r] = (int)$row['jumlah']; }

$admin = $_SESSION['user'] ?? [];
$profileSrc = 'assets/img/default-profile.png';
if (!empty($admin['foto']) && file_exists(__DIR__ . '/../upload/' . $admin['foto'])) {
    $profileSrc = '../upload/' . $admin['foto'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Dashboard Admin — PPID</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
  --primary:#2563eb; --primary-2:#60a5fa;
  --success:#16a34a; --warning:#f59e0b; --danger:#ef4444; --info:#0ea5e9;
  --bg:#f6f8fc; --card:#ffffff; --text:#0f172a; --muted:#64748b; --line:#e9eef5;
  --ring:rgba(37,99,235,.22); --shadow:0 10px 28px rgba(2,6,23,.08); --radius:14px;
}
*{box-sizing:border-box} html,body{margin:0}
body{font-family:'Inter',system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--text)}

/* ====== Layout (sinkron sidebar) ====== */
main#main{
  margin-left:260px; padding:18px; min-height:100svh; transition:margin-left .25s ease;
}
main#main.expanded{ margin-left:0; }
.container{ max-width:1280px; margin:0 auto; }

/* ====== HERO super-compact ====== */
.hero{
  display:grid; grid-template-columns:1fr auto; gap:12px;
  padding:14px 16px; border:1px solid var(--line); border-radius:var(--radius);
  background:
    radial-gradient(700px 220px at -10% -30%, #93c5fd55 0%, transparent 60%),
    radial-gradient(480px 220px at 120% -20%, #86efac55 0%, transparent 60%),
    linear-gradient(180deg,#ffffff,#f8fafc);
  box-shadow: var(--shadow);
}
.hero .title{font-weight:800; font-size:18px; letter-spacing:.2px; display:flex; align-items:center; gap:8px}
.hero .title .dot{width:8px; height:8px; background:linear-gradient(90deg,var(--primary),var(--primary-2)); border-radius:999px; display:inline-block}
.hero .sub{color:var(--muted); font-size:12px; margin-top:4px}

.actions{display:flex; align-items:center; gap:8px; flex-wrap:wrap}
.btn{border:1px solid var(--line); background:#fff; color:#0b1220; border-radius:10px; padding:8px 10px; cursor:pointer;
     display:inline-flex; align-items:center; gap:8px; box-shadow:0 4px 12px rgba(2,6,23,.04); transition:transform .12s, background .2s}
.btn:hover{transform:translateY(-1px); background:#f9fbff}
.btn:focus{outline:3px solid var(--ring)}
.btn-primary{background:linear-gradient(180deg,var(--primary),#1e40af); color:#fff; border-color:transparent}
.profile{display:flex; align-items:center; gap:10px; padding-left:6px}
.profile img{width:40px; height:40px; border-radius:10px; object-fit:cover; border:1px solid #e2e8f0}
.profile .name{font-weight:700; font-size:13px}
.profile .role{color:var(--muted); font-size:11px}

/* ====== GRID METRICS — rapat, tanpa ruang kosong ====== */
.grid{display:grid; grid-template-columns:repeat(12,1fr); gap:10px; margin-top:12px}
.card{
  grid-column:span 3; background:var(--card); border-radius:12px; padding:14px;
  border:1px solid var(--line); box-shadow:var(--shadow); position:relative; overflow:hidden;
  animation:fadeUp .35s ease both;
}
.card .top{display:flex; align-items:center; justify-content:space-between; gap:8px}
.card .meta{color:var(--muted); font-size:11px; font-weight:700; letter-spacing:.35px; text-transform:uppercase}
.card .value{font-size:24px; font-weight:800; margin-top:6px}
.card .chip{font-size:10px; padding:4px 8px; border-radius:999px; border:1px solid var(--line); color:#475569; background:#f8fafc}
.card i{font-size:16px; padding:8px; border-radius:10px; background:#f1f5ff}
.card.total i{color:#1d4ed8; background:#dbeafe}
.card.menunggu i{color:#b45309; background:#ffedd5}
.card.sedang i{color:#0369a1; background:#e0f2fe}
.card.selesai i{color:#047857; background:#dcfce7}
.card.ditolak i{color:#b91c1c; background:#fee2e2}
.card:after{content:""; position:absolute; inset:auto 0 0 0; height:3px; opacity:.95}
.card.total:after{background:linear-gradient(90deg,var(--primary),var(--primary-2))}
.card.menunggu:after{background:linear-gradient(90deg,#f59e0b,#fbbf24)}
.card.sedang:after{background:linear-gradient(90deg,#0ea5e9,#38bdf8)}
.card.selesai:after{background:linear-gradient(90deg,#16a34a,#34d399)}
.card.ditolak:after{background:linear-gradient(90deg,#ef4444,#f87171)}
.grid .card:nth-child(1){animation-delay:.02s}
.grid .card:nth-child(2){animation-delay:.06s}
.grid .card:nth-child(3){animation-delay:.1s}
.grid .card:nth-child(4){animation-delay:.14s}
.grid .card:nth-child(5){animation-delay:.18s}

/* ====== PANELS CHART — compact ====== */
.panels{display:grid; grid-template-columns:repeat(12,1fr); gap:10px; margin-top:10px}
.panel{
  grid-column:span 6; background:var(--card); border-radius:12px; padding:14px; border:1px solid var(--line); box-shadow:var(--shadow);
  animation:fadeUp .35s ease both;
}
.panel.small{grid-column:span 6}
.panel .title{font-weight:800; font-size:13px; letter-spacing:.2px; margin-bottom:8px}
.panel .canvas{height:260px}

/* ====== Footer tip ====== */
.tip{margin-top:10px; color:var(--muted); font-size:11px}

/* ====== Animations ====== */
@keyframes fadeUp{from{opacity:0; transform:translateY(6px)} to{opacity:1; transform:translateY(0)}}

/* ====== Responsive ====== */
@media (max-width:1200px){
  .card{grid-column:span 5}
  .panel{grid-column:span 12}
}
@media (max-width:768px){
  main#main{margin-left:0; padding:14px}
  .card{grid-column:span 5}
  .hero{grid-template-columns:1fr; gap:8px}
  .actions{justify-content:space-between}
}

/* ====== Dark (auto) ====== */
@media (prefers-color-scheme: dark){
  :root{ --bg:#0b1020; --card:#0f172a; --text:#e5e7eb; --muted:#9aa4b2; --line:#1e293b; --shadow:0 10px 26px rgba(0,0,0,.45); }
  .btn{background:#0b1224; color:#e5e7eb; border-color:#1f2937}
  .hero{ background:
    radial-gradient(700px 220px at -10% -30%, #1d4ed855 0%, transparent 60%),
    radial-gradient(480px 220px at 120% -20%, #16a34a55 0%, transparent 60%),
    linear-gradient(180deg,#0f172a,#0b1325);}
}
</style>
</head>
<body>

<main id="main">
  <div class="container">
    <!-- HERO -->
    <section class="hero" role="banner" aria-label="Ringkasan">
      <div>
        <div class="title"><span class="dot"></span> Selamat Datang, <?= htmlspecialchars($admin['username'] ?? $admin['nama'] ?? 'Admin') ?> 👋</div>
        <div class="sub">Pantau performa layanan informasi & aktivitas terbaru — <?= date('d M Y') ?>.</div>
      </div>
      <div class="actions">
        <!-- <button class="btn" id="toggleTheme" type="button" title="Tema"><i class="fa-solid fa-moon"></i><span style="font-size:12px">Tema</span></button> -->
        <!-- <button class="btn" id="collapseSidebar" type="button" title="Sembunyikan/lihat sidebar"><i class="fa-solid fa-table-columns"></i><span style="font-size:12px">Sidebar</span></button> -->
        <button class="btn btn-primary" type="button" onclick="location.reload()" title="Muat ulang"><i class="fa-solid fa-rotate"></i><span style="font-size:12px">Refresh</span></button>
        <div class="profile">
          <img src="<?= htmlspecialchars($profileSrc) ?>" alt="Foto admin">
          <div>
            <div class="name"><?= htmlspecialchars($admin['username'] ?? $admin['nama'] ?? 'Admin') ?></div>
            <div class="role">Administrator</div>
          </div>
        </div>
      </div>
    </section>

    <!-- METRICS -->
    <section class="grid" aria-label="Ringkasan metrik">
      <div class="card total">
        <div class="top"><span class="meta">Total</span><i class="fa-solid fa-inbox"></i></div>
        <div class="value"><?= number_format($counts['total']) ?></div>
        <span class="chip">Semua status</span>
      </div>
      <div class="card menunggu">
        <div class="top"><span class="meta">Menunggu</span><i class="fa-solid fa-hourglass-half"></i></div>
        <div class="value"><?= number_format($counts['menunggu']) ?></div>
        <span class="chip">Butuh tindak lanjut</span>
      </div>
      <div class="card sedang">
        <div class="top"><span class="meta">Diproses</span><i class="fa-solid fa-gears"></i></div>
        <div class="value"><?= number_format($counts['sedang']) ?></div>
        <span class="chip">Dalam penanganan</span>
      </div>
      <div class="card selesai">
        <div class="top"><span class="meta">Selesai</span><i class="fa-solid fa-circle-check"></i></div>
        <div class="value"><?= number_format($counts['selesai']) ?></div>
        <span class="chip">Tuntas</span>
      </div>
      <div class="card ditolak">
        <div class="top"><span class="meta">Ditolak</span><i class="fa-solid fa-circle-xmark"></i></div>
        <div class="value"><?= number_format($counts['ditolak']) ?></div>
        <span class="chip">Tidak memenuhi kriteria</span>
      </div>
    </section>

    <!-- CHARTS -->
    <section class="panels" aria-label="Visualisasi">
      <div class="panel small">
        <div class="title">Distribusi Status Permohonan</div>
        <div class="canvas"><canvas id="statusChart"></canvas></div>
      </div>
      <div class="panel">
        <div class="title">Jumlah Permohonan per Bulan</div>
        <div class="canvas"><canvas id="trendChart"></canvas></div>
      </div>
      <div class="panel">
        <div class="title">Pertumbuhan Permohonan</div>
        <div class="canvas"><canvas id="growthChart"></canvas></div>
      </div>
      <div class="panel small">
        <div class="title">Distribusi Rating Komentar</div>
        <div class="canvas"><canvas id="ratingChart"></canvas></div>
      </div>
    </section>

    <p class="tip">Tip: klik “Sidebar” untuk menyembunyikan panel kiri. Area kerja otomatis melebar, tanpa ruang kosong.</p>
  </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
/* ===== Sidebar sync: lebar konten menyesuaikan ===== */
(() => {
  const sidebar = document.getElementById('sidebar');
  const collapseBtn = document.getElementById('collapseBtn');      // dari admin_sidebar.php
  const openSidebarBtn = document.getElementById('openSidebarBtn'); // dari admin_sidebar.php
  const main = document.getElementById('main');
  const myToggle = document.getElementById('collapseSidebar');      // tombol cepat di hero

  function collapse(){
    sidebar?.classList.add('collapsed');
    if (openSidebarBtn) openSidebarBtn.style.display = 'block';
    main.classList.add('expanded');
  }
  function expand(){
    sidebar?.classList.remove('collapsed');
    sidebar?.classList.add('show');
    if (openSidebarBtn) openSidebarBtn.style.display = 'none';
    main.classList.remove('expanded');
  }
  collapseBtn && collapseBtn.addEventListener('click', collapse);
  openSidebarBtn && openSidebarBtn.addEventListener('click', expand);
  myToggle && myToggle.addEventListener('click', ()=> sidebar?.classList.contains('collapsed') ? expand() : collapse());
  window.addEventListener('resize', () => {
    if (window.innerWidth > 992){
      sidebar?.classList.remove('show','collapsed');
      main.classList.remove('expanded');
      if (openSidebarBtn) openSidebarBtn.style.display = 'none';
    }
  });
})();

/* ===== Theme toggle (persist) ===== */
(() => {
  const KEY='ppid-theme'; const btn=document.getElementById('toggleTheme');
  const apply = m => { document.documentElement.style.colorScheme=m==='dark'?'dark':'light'; document.body.dataset.theme=m; };
  const saved = localStorage.getItem(KEY); if (saved) apply(saved);
  btn?.addEventListener('click', ()=>{ const next=(document.body.dataset.theme==='dark')?'light':'dark'; localStorage.setItem(KEY,next); apply(next); });
})();

/* ===== Chart.js setup ===== */
Chart.defaults.font.family = "'Inter', system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif";
Chart.defaults.animation.duration = 900;
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.position = 'bottom';

const monthly = <?= json_encode(array_values($monthlyData)) ?>;
const labels12 = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];

new Chart(document.getElementById('statusChart'), {
  type:'doughnut',
  data:{
    labels:['Menunggu','Diproses','Selesai','Ditolak'],
    datasets:[{
      data:[<?= $counts['menunggu'] ?>, <?= $counts['sedang'] ?>, <?= $counts['selesai'] ?>, <?= $counts['ditolak'] ?>],
      backgroundColor:['#f59e0b','#0ea5e9','#16a34a','#ef4444'],
      borderWidth:0
    }]
  },
  options:{
    cutout:'60%',
    plugins:{ tooltip:{callbacks:{label:(c)=>`${c.label}: ${c.raw.toLocaleString('id-ID')}`}}}
  }
});

new Chart(document.getElementById('trendChart'), {
  type:'bar',
  data:{
    labels:labels12,
    datasets:[{
      label:'Jumlah Permohonan',
      data:monthly,
      backgroundColor:'#2563eb',
      borderRadius:8,
      barThickness:'flex',
      maxBarThickness:40
    }]
  },
  options:{
    scales:{ y:{ beginAtZero:true, grid:{ color:'rgba(148,163,184,.22)'} }, x:{ grid:{ display:false } } },
    plugins:{ legend:{ display:false }, tooltip:{ callbacks:{ label:(c)=>`${c.dataset.label}: ${c.raw.toLocaleString('id-ID')}` } } }
  }
});

new Chart(document.getElementById('growthChart'), {
  type:'line',
  data:{
    labels:labels12,
    datasets:[{
      label:'Pertumbuhan Permohonan',
      data:monthly,
      borderColor:'#16a34a',
      backgroundColor:'rgba(22,163,74,.18)',
      tension:.35,
      fill:true,
      pointRadius:3.5,
      pointHoverRadius:5,
      pointBackgroundColor:'#16a34a',
      pointBorderColor:'#fff',
      pointBorderWidth:2
    }]
  },
  options:{
    scales:{ y:{ beginAtZero:true, grid:{ color:'rgba(148,163,184,.22)'} }, x:{ grid:{ display:false } } },
    plugins:{ tooltip:{ callbacks:{ label:(c)=>`${c.dataset.label}: ${c.raw.toLocaleString('id-ID')}` } } }
  }
});

new Chart(document.getElementById('ratingChart'), {
  type:'pie',
  data:{
    labels:['Rating 1','Rating 2','Rating 3','Rating 4','Rating 5'],
    datasets:[{
      data: <?= json_encode(array_values($ratingCounts)) ?>,
      backgroundColor:['#ef4444','#f97316','#f59e0b','#22c55e','#16a34a'],
      borderWidth:0
    }]
  },
  options:{ plugins:{ tooltip:{ callbacks:{ label:(c)=>`${c.label}: ${c.raw.toLocaleString('id-ID')}` } } } }
});
</script>
</body>
</html>
