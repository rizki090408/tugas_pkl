<?php
session_start();
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}
include '../includes/koneksi.php';
include '../includes/admin_sidebar.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<title>Umpan Balik - Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">

<style>
:root {
    --bg:#f6f8fb;
    --card:#ffffff;
    --muted:#64748b;
    --text:#0f172a;
    --accent:#2563eb;
    --danger:#ef4444;
    --radius:10px;
    --gap:12px;
    --table-border:#e6eef9;
}
body {
    margin:0;
    background:var(--bg);
    font-family:'Inter',sans-serif;
    color:var(--text);
}

/* Pastikan main mengikuti sidebar */
main {
    margin-left: 250px;
    transition: margin-left 0.3s ease;
}
main.expanded {
    margin-left: 0;
}

/* Page container */
.page-container {
    padding:20px;
    max-width:1200px;
    margin:auto;
}

.header {
    display:flex;
    flex-wrap:wrap;
    gap:var(--gap);
    align-items:center;
    margin-bottom:var(--gap);
}
.header .title h1 { margin:0;font-size:22px;font-weight:600; }
.header .title p { margin:0;color:var(--muted);font-size:14px; }
.controls {
    display:flex;
    flex-wrap:wrap;
    gap:var(--gap);
    align-items:center;
    margin-left:auto;
}
.search {
    display:flex;
    align-items:center;
    background:var(--card);
    border:1px solid var(--table-border);
    border-radius:var(--radius);
    padding:6px 10px;
}
.search input {
    border:none;
    outline:none;
    padding:4px;
    font-size:14px;
    background:none;
}
.perpage {
    border:1px solid var(--table-border);
    border-radius:var(--radius);
    padding:6px 10px;
    background:var(--card);
}
.card {
    background:var(--card);
    border-radius:var(--radius);
    padding:var(--gap);
    box-shadow:0 2px 4px rgba(0,0,0,0.05);
}
.table-wrap { overflow-x:auto; }
table.feedback {
    border-collapse:collapse;
    width:100%;
}
.feedback th,.feedback td {
    border-bottom:1px solid var(--table-border);
    padding:8px 10px;
    text-align:left;
    font-size:14px;
}
.feedback th {
    background:#f8fafc;
    font-weight:600;
    color:var(--muted);
    cursor:pointer;
}
.feedback tr:hover td {
    background:#f9fbff;
}
.rating {
    display:inline-block;
    padding:2px 6px;
    border-radius:6px;
    font-size:13px;
    font-weight:500;
}
.rating.r-5 { background:#dcfce7;color:#15803d; }
.rating.r-4 { background:#fef9c3;color:#a16207; }
.rating.r-3 { background:#fee2e2;color:#b91c1c; }
.rating.r-2,.rating.r-1 { background:#fecaca;color:#7f1d1d; }
.btn-hapus {
    background:var(--danger);
    color:#fff;
    border:none;
    border-radius:6px;
    padding:4px 8px;
    font-size:12px;
    cursor:pointer;
}
.pager {
    display:flex;
    gap:8px;
    align-items:center;
    justify-content:flex-end;
    margin-top:var(--gap);
}
.pager button {
    padding:4px 8px;
    border-radius:6px;
    border:1px solid var(--table-border);
    background:var(--card);
    cursor:pointer;
}
/* Export dropdown */
.export-dropdown { position: relative; display: inline-block; margin-bottom: 10px; }
.export-btn {
    background: var(--card);
    border: 1px solid var(--table-border);
    border-radius: 8px;
    padding: 6px 10px;
    font-size: 13px;
    cursor: pointer;
    color: var(--text);
}
.export-menu {
    display: none;
    position: absolute;
    background: var(--card);
    border: 1px solid var(--table-border);
    border-radius: 8px;
    min-width: 120px;
    z-index: 10;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
.export-menu a {
    display: block;
    padding: 6px 10px;
    font-size: 13px;
    color: var(--text);
    text-decoration: none;
}
.export-menu a:hover { background: #f1f5f9; }
.export-dropdown:hover .export-menu { display: block; }
</style>
</head>
<body>

<main>
<div class="page-container">
  <div class="header">
    <div class="title">
      <h1>Umpan Balik Pengguna</h1>
      <p>Kelola komentar dan rating dari pengguna — mudah & cepat.</p>
    </div>

    <div class="controls">
      <div class="search" role="search">
        <i class="fa fa-search" style="color:var(--muted)"></i>
        <input id="q" type="search" placeholder="Cari..." aria-label="Cari">
      </div>

      <select id="perPage" class="perpage">
        <option value="5">5 / halaman</option>
        <option value="10" selected>10 / halaman</option>
        <option value="20">20 / halaman</option>
      </select>
    </div>
  </div>

  <div class="card">
    <!-- Tombol Export -->
    <div class="export-dropdown">
      <button class="export-btn"><i class="fa fa-download"></i> Export</button>
      <div class="export-menu">
        <a href="#" id="exportExcel">📊 Excel</a>
        <a href="#" id="exportPDF">📄 PDF</a>
        <a href="#" id="exportPrint">🖨️ Print</a>
        <a href="#" id="exportWord">📝 Word</a>
      </div>
    </div>

    <div class="table-wrap">
      <table class="feedback" id="fbTable">
        <thead>
          <tr>
            <th data-sort="nama">Nama</th>
            <th>Komentar</th>
            <th data-sort="rating">Rating</th>
            <th data-sort="tanggal">Tanggal</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody id="tbody">
        <?php
        $result = mysqli_query($koneksi, "SELECT * FROM umpan_balik ORDER BY id DESC");
        $allData = [];
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $id = (int)$row['id'];
                $nama = htmlspecialchars($row['nama']);
                $komentar = htmlspecialchars($row['komentar']);
                $rating = (int)$row['rating'];
                $tgl = date("Y-m-d", strtotime($row['tanggal']));
                $tglDisplay = date("d M Y", strtotime($row['tanggal']));
                $rclass = "r-".max(1,min(5,$rating));
                $allData[] = [$nama, $komentar, "$rating / 5", $tglDisplay];
                echo "<tr data-nama=\"{$nama}\" data-rating=\"{$rating}\" data-tanggal=\"{$tgl}\">
                        <td>{$nama}</td>
                        <td>{$komentar}</td>
                        <td><span class=\"rating {$rclass}\">{$rating} / 5</span></td>
                        <td>{$tglDisplay}</td>
                        <td><button class=\"btn-hapus\" data-id=\"{$id}\">Hapus</button></td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5' style='text-align:center;color:var(--muted);padding:18px'>Belum ada umpan balik</td></tr>";
        }
        ?>
        </tbody>
      </table>
    </div>

    <div class="pager" id="pager">
      <div id="pagerInfo">Menampilkan <span id="showing">0</span> dari <span id="totalRows">0</span></div>
      <div style="flex:1"></div>
      <button id="prev">Prev</button>
      <button id="next">Next</button>
    </div>
  </div>
</div>
</main>

<!-- Modal backdrop -->
<div class="modal-backdrop" id="modalBackdrop" style="display:none;"></div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>

<script>
const allData = <?php echo json_encode($allData, JSON_UNESCAPED_UNICODE); ?>;

// Export Excel
$('#exportExcel').click(function(e){
  e.preventDefault();
  const table = [['Nama','Komentar','Rating','Tanggal'], ...allData];
  let csvContent = "data:application/vnd.ms-excel;charset=utf-8,";
  table.forEach(row => {
    csvContent += row.map(v => `"${v}"`).join(",") + "\n";
  });
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "Laporan_Umpan_Balik.xls");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
});

// Export PDF
$('#exportPDF').click(function(e){
  e.preventDefault();
  const docDefinition = {
    content: [
      { text: 'Laporan Umpan Balik', style: 'header' },
      {
        table: {
          headerRows: 1,
          widths: ['auto', '*', 'auto', 'auto'],
          body: [['Nama','Komentar','Rating','Tanggal'], ...allData]
        }
      }
    ],
    styles: { header: { fontSize: 16, bold: true, margin: [0,0,0,10] } },
    pageOrientation: 'landscape'
  };
  pdfMake.createPdf(docDefinition).download('Laporan_Umpan_Balik.pdf');
});

// Export Print
$('#exportPrint').click(function(e){
  e.preventDefault();
  let html = '<html><head><title>Print</title></head><body>';
  html += '<h2>Laporan Umpan Balik</h2>';
  html += '<table border="1" cellspacing="0" cellpadding="5"><tr><th>Nama</th><th>Komentar</th><th>Rating</th><th>Tanggal</th></tr>';
  allData.forEach(row => {
    html += `<tr><td>${row[0]}</td><td>${row[1]}</td><td>${row[2]}</td><td>${row[3]}</td></tr>`;
  });
  html += '</table></body></html>';
  const win = window.open('', '', 'width=800,height=600');
  win.document.write(html);
  win.print();
});

// Export Word
$('#exportWord').click(function(e){
  e.preventDefault();
  let html = '<table border="1" cellspacing="0" cellpadding="5"><tr><th>Nama</th><th>Komentar</th><th>Rating</th><th>Tanggal</th></tr>';
  allData.forEach(row => {
    html += `<tr><td>${row[0]}</td><td>${row[1]}</td><td>${row[2]}</td><td>${row[3]}</td></tr>`;
  });
  html += '</table>';
  const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Laporan_Umpan_Balik.doc';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
});
</script>
</body>
</html>
