<?php
session_start();

// Cek login dan hak akses
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Koneksi database
require_once '../includes/koneksi.php';
require_once '../includes/admin_sidebar.php';

// Ambil data permohonan
$query = mysqli_query($koneksi, "SELECT * FROM permohonan ORDER BY id DESC");
if (!$query) {
    die("Query gagal: " . mysqli_error($koneksi));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tabel Permohonan - Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
        }
        /* Sidebar (tidak diubah styling-nya sesuai permintaan) */

        /* Konten utama */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
            width: 100%;
        }
        .main-content.full {
            margin-left: 0;
        }
        /* Tombol toggle */
        .toggle-btn {
            background: #3498db;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        th {
            background: #3498db;
            color: white;
        }
    </style>
</head>
<body>

    <div class="main-content" id="main">
        <button class="toggle-btn" onclick="toggleSidebar()">☰ Menu</button>
        <h1>Daftar Permohonan Informasi</h1>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pemohon</th>
                    <th>Email</th>
                    <th>Informasi Diminta</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($query) > 0): ?>
                    <?php $no = 1; ?>
                    <?php while ($row = mysqli_fetch_assoc($query)): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= htmlspecialchars($row['nama']); ?></td>
                            <td><?= htmlspecialchars($row['email']); ?></td>
                            <td><?= htmlspecialchars($row['informasi']); ?></td>
                            <td><?= htmlspecialchars($row['tanggal']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align:center;">Tidak ada data permohonan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('hide');
            document.getElementById('main').classList.toggle('full');
        }
    </script>

</body>
</html>
