<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/koneksi.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
mysqli_query($koneksi, "DELETE FROM umpan_balik WHERE id = $id");

header("Location: umpan_balik.php");
exit();
?>