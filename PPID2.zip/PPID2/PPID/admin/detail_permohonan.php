<?php
session_start();
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

include '../includes/koneksi.php';

// Update status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['status'])) {
    $id = intval($_POST['id']);
    $status = mysqli_real_escape_string($koneksi, $_POST['status']);
    mysqli_query($koneksi, "UPDATE permohonan SET status = '$status' WHERE id = $id");
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$result = mysqli_query($koneksi, "SELECT * FROM permohonan ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Permohonan - Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
    --primary: #2563eb;
    --primary-dark: #1e40af;
    --bg: #f8fafc;
    --card: #fff;
    --text: #1f2937;
}
* {margin:0;padding:0;box-sizing:border-box;font-family:'Inter',sans-serif;}
body {background:var(--bg);color:var(--text);}
main {margin-left:250px;padding:20px;}
.card {background:var(--card);padding:20px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.05);}
h2 {color:var(--primary);margin-bottom:15px;}
table {width:100%;border-collapse:collapse;font-size:14px;}
th,td {padding:10px 12px;text-align:left;}
thead {background:var(--primary);color:white;}
tbody tr:nth-child(even) {background:#f9fafb;}
tbody tr:hover {background:rgba(37,99,235,0.05);}
.status-badge {padding:4px 10px;border-radius:20px;font-size:12px;color:white;font-weight:600;}
.status-menunggu {background:#f59e0b;}
.status-sedang {background:#3b82f6;}
.status-selesai {background:#10b981;}
.status-ditolak {background:#ef4444;}
select,button {padding:5px 8px;border-radius:6px;border:1px solid #ccc;font-size:13px;}
select:focus {border-color:var(--primary);outline:none;}
button {background:var(--primary);color:white;border:none;cursor:pointer;}
button:hover {background:var(--primary-dark);}
@media(max-width:992px){main{margin-left:0;padding:15px;}table{font-size:13px;}}
</style>
</head>
<body>

<?php include '../includes/admin_sidebar.php'; ?>

<main>
    <div class="card">
        <h2>Data Permohonan Informasi</h2>
        <table>
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>No HP</th>
                    <th>Informasi Diminta</th>
                    <th>Tujuan</th>
                    <th>Dokumen</th>
                    <th>Status</th>
                    <th>Update Status</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['no_hp']) ?></td>
                    <td><?= htmlspecialchars($row['informasi']) ?></td>
                    <td><?= htmlspecialchars($row['tujuan']) ?></td>
                    <td>
                        <?php if (!empty($row['dokumen'])): ?>
                            <a href="../upload/<?= htmlspecialchars($row['dokumen']) ?>" target="_blank">📄 Lihat</a>
                        <?php else: ?> - <?php endif; ?>
                    </td>
                    <td>
                        <span class="status-badge 
                            <?= $row['status']=='menunggu'?'status-menunggu':'' ?>
                            <?= $row['status']=='sedang diproses'?'status-sedang':'' ?>
                            <?= $row['status']=='selesai'?'status-selesai':'' ?>
                            <?= $row['status']=='ditolak'?'status-ditolak':'' ?>">
                            <?= ucfirst($row['status']) ?>
                        </span>
                    </td>
                    <td>
                        <form method="post" style="display:flex;gap:5px;align-items:center;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <select name="status" required>
                                <option value="">--Pilih--</option>
                                <option value="menunggu" <?= $row['status']=='menunggu'?'selected':'' ?>>Menunggu</option>
                                <option value="sedang diproses" <?= $row['status']=='sedang diproses'?'selected':'' ?>>Sedang Diproses</option>
                                <option value="selesai" <?= $row['status']=='selesai'?'selected':'' ?>>Selesai</option>
                                <option value="ditolak" <?= $row['status']=='ditolak'?'selected':'' ?>>Ditolak</option>
                            </select>
                            <button type="submit"><i class="fas fa-check"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</main>

</body>
</html>
