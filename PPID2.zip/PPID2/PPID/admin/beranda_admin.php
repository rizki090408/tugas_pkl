<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/koneksi.php';

// Statistik
$permohonan = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM permohonan"));
$proses = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM permohonan WHERE status = 'sedang diproses'"));
$selesai = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM permohonan WHERE status = 'selesai'"));
$umpan_balik = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM umpan_balik"));

// Permohonan terbaru
$recent_permohonan = mysqli_query($koneksi, "SELECT * FROM permohonan ORDER BY tanggal DESC LIMIT 20");

// Informasi terbaru
$recent_info = mysqli_query($koneksi, "SELECT * FROM informasi WHERE tanggal <= CURDATE() ORDER BY tanggal DESC LIMIT 5");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Beranda Admin - PPID BBPMP Jabar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * { box-sizing: border-box; font-family: 'Inter', sans-serif; }
    body { background: #f4f6f9; margin: 0; padding: 0; color: #333; }
    header {
      background: #1a32b6; color: white; padding: 25px; text-align: center;
    }
    .container {
      max-width: 1100px; margin: 40px auto; background: white; padding: 30px;
      border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.08);
    }
    h2 { color: #1a32b6; margin-bottom: 20px; }
    .stats { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 30px; }
    .card {
      flex: 1; background: #f0f2f7; padding: 20px; border-radius: 10px;
      min-width: 200px; text-align: center; box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
    .card h3 { margin: 0; font-size: 26px; color: #1a32b6; }
    .card p { margin-top: 8px; font-size: 14px; color: #555; }
    table {
      width: 100%; border-collapse: collapse; margin: 0;
    }
    th, td {
      padding: 10px; border-bottom: 1px solid #eee; text-align: left;
    }
    th { background: #f9f9f9; color: #333; }
    .btn {
      display: inline-block; margin: 15px 5px 0 0; padding: 10px 16px;
      background: #1a32b6; color: white; border-radius: 6px;
      text-decoration: none; font-size: 14px;
    }
    .btn2 {
      display: inline-block; margin: 15px 5px 0 0; padding: 10px 16px;
      background: #f34905; color: white; border-radius: 6px;
      text-decoration: none; font-size: 14px;
    }
    .btn:hover { background: #142194; }
    .section { margin-top: 40px; }

    .scroll-table {
      max-height: 300px;
      overflow-y: auto;
      border: 1px solid #ddd;
      border-radius: 6px;
      margin-top: 15px;
    }

    .scroll-table::-webkit-scrollbar {
      width: 8px;
    }

    .scroll-table::-webkit-scrollbar-thumb {
      background-color: #ccc;
      border-radius: 4px;
    }
  </style>
</head>
<body>

<header>
  <h1>Beranda Admin - PPID BBPMP Jabar</h1>
  <p>Selamat datang, <?= htmlspecialchars($_SESSION['username']) ?> 👋</p>
</header>

<div class="container">
  <h2>Statistik Sistem</h2>
  <div class="stats">
    <div class="card"><h3><?= $permohonan ?></h3><p>Total Permohonan</p></div>
    <div class="card"><h3><?= $proses ?></h3><p>Diproses</p></div>
    <div class="card"><h3><?= $selesai ?></h3><p>Selesai</p></div>
    <div class="card"><h3><?= $umpan_balik ?></h3><p>Umpan Balik</p></div>
  </div>

  <div class="section">
    <h2>Permohonan Terbaru</h2>
    <div class="scroll-table">
      <table>
        <tr><th>Nama</th><th>Email</th><th>Status</th><th>Tanggal</th></tr>
        <?php while($p = mysqli_fetch_assoc($recent_permohonan)): ?>
          <tr>
            <td><?= htmlspecialchars($p['nama']) ?></td>
            <td><?= htmlspecialchars($p['email']) ?></td>
            <td><?= htmlspecialchars($p['status']) ?></td>
            <td><?= date('d M Y', strtotime($p['tanggal'])) ?></td>
          </tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>

  <div class="section">
    <h2>Informasi Publik Terbaru</h2>
    <a class="btn" href="tambah_informasi.php">Tambah</a>
    <table>
      <tr><th>Judul</th><th>Gambar</th><th>Tanggal</th><th>Aksi</th></tr>
      <?php while($i = mysqli_fetch_assoc($recent_info)): ?>
        <tr>
          <td><?= htmlspecialchars($i['judul']) ?></td>
          <td><img src="../upload/<?= htmlspecialchars($i['gambar']) ?>" width="80"></td>
          <td><?= date('d M Y', strtotime($i['tanggal'])) ?></td>
          <td>
            <a href="hapus_informasi.php?id=<?= $i['id'] ?>" onclick="return confirm('Yakin ingin menghapus informasi ini?')" class="btn2">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

  <div class="section">
    <a class="btn" href="home.php" style="background:#e74c3c;">Kembali</a>
  </div>
</div>

</body>
</html>
