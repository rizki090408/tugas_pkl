<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/koneksi.php';

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul     = trim($_POST['judul']);
    $deskripsi = trim($_POST['deskripsi']);
    $tanggal   = date('Y-m-d');
    $gambar    = "";

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === 0) {
        $uploadDir = '../upload/';
        $namaFile  = time() . "_" . preg_replace("/[^a-zA-Z0-9\.\-_]/", "", basename($_FILES['gambar']['name']));
        $gambar    = $namaFile;

        move_uploaded_file($_FILES['gambar']['tmp_name'], $uploadDir . $gambar);
    }

    if ($judul && $deskripsi && $gambar) {
        $stmt = mysqli_prepare($koneksi, "INSERT INTO informasi (judul, deskripsi, gambar, tanggal) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $judul, $deskripsi, $gambar, $tanggal);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header("Location: home.php");
        exit();
    } else {
        $error = "Semua field wajib diisi dan gambar harus diunggah.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Informasi</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }

    body {
      margin: 0;
      background: #f4f6f9;
      padding: 60px 20px;
    }

    .container {
      max-width: 640px;
      margin: auto;
      background: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 6px 24px rgba(0,0,0,0.08);
      position: relative;
    }

    h2 {
      font-size: 24px;
      color: #1a32b6;
      text-align: center;
      margin-bottom: 30px;
    }

    .form-group {
      position: relative;
      margin-bottom: 28px;
    }

    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 14px 16px;
      border: 1px solid #ccc;
      border-radius: 8px;
      background: #fff;
      font-size: 14px;
      outline: none;
      transition: border-color 0.3s;
    }

    .form-group textarea {
      resize: vertical;
      min-height: 120px;
    }

    .form-group input:focus,
    .form-group textarea:focus {
      border-color: #1a32b6;
    }

    .form-group label {
      position: absolute;
      top: -10px;
      left: 14px;
      background: #fff;
      padding: 0 6px;
      font-size: 13px;
      color: #1a32b6;
      font-weight: 600;
    }

    .form-group input[type="file"] {
      padding: 10px;
    }

    .error-message {
      background: #ffefef;
      color: #cc0000;
      border: 1px solid #f5c2c7;
      padding: 14px 18px;
      border-radius: 8px;
      margin-bottom: 25px;
      font-size: 14px;
    }

    button {
      width: 100%;
      padding: 14px;
      background-color: #1a32b6;
      color: #fff;
      font-weight: 600;
      border: none;
      border-radius: 10px;
      font-size: 16px;
      transition: background 0.3s ease;
      cursor: pointer;
    }

    button:hover {
      background-color: #122593;
    }

    @media (max-width: 500px) {
      .container {
        padding: 30px 20px;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Tambah Informasi Baru</h2>

    <?php if ($error): ?>
      <div class="error-message"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
      <div class="form-group">
        <label for="judul">Judul</label>
        <input type="text" name="judul" id="judul" required>
      </div>

      <div class="form-group">
        <label for="deskripsi">Deskripsi</label>
        <textarea name="deskripsi" id="deskripsi" required></textarea>
      </div>

      <div class="form-group">
        <label for="gambar">Unggah Gambar</label>
        <input type="file" name="gambar" id="gambar" accept="image/*" required>
      </div>

      <button type="submit">Simpan Informasi</button>
    </form>
  </div>
</body>
</html>
