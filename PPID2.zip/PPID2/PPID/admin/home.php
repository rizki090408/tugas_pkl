<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}
include '../includes/koneksi.php';
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Home Admin - PPID BBPMP Jabar</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }
    body {
      background: #f2f4f8;
      color: #333;
    }
    header {
      background-color: #1a32b6;
      color: white;
      padding: 25px;
      text-align: center;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    header h1 {
      font-size: 24px;
    }

    .container {
      max-width: 1000px;
      margin: 40px auto;
      background: white;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.08);
      text-align: center;
    }

    .welcome {
      font-size: 18px;
      margin-bottom: 30px;
      color: #444;
    }

    .card-grid {
      display: flex;
      justify-content: center;
      gap: 30px;
      flex-wrap: wrap;
    }

    .card {
      background: #f9f9f9;
      padding: 30px;
      border-radius: 14px;
      text-align: center;
      width: 220px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.06);
      transition: 0.3s;
      text-decoration: none;
      color: #1a1a1a;
    }

    .card:hover {
      background: #1a32b6;
      color: white;
      transform: translateY(-5px);
    }

    .card-icon {
      font-size: 40px;
      margin-bottom: 10px;
    }

    .logout {
      display: inline-block;
      margin-top: 40px;
      padding: 10px 20px;
      background: #e74c3c;
      color: white;
      border-radius: 8px;
      text-decoration: none;
      transition: 0.3s;
    }

    .logout:hover {
      background: #c0392b;
    }

    @media (max-width: 768px) {
      .card {
        width: 100%;
      }
    }
  </style>
</head>
<body>

<header>
  <h1>Selamat Datang, Admin <?= htmlspecialchars($_SESSION['user']['username']) ?> 👋</h1>

</header>

<div class="container">
  <p class="welcome">Silakan pilih menu berikut untuk mengelola informasi publik PPID BBPMP Jabar.</p>

  <div class="card-grid">
    <a href="dashboard.php" class="card">
      <div class="card-icon">📊</div>
      <div>Dashboard</div>
    </a>
    <a href="umpan_balik.php" class="card">
      <div class="card-icon">💬</div>
      <div>Umpan Balik</div>
    </a>
    <a href="beranda_admin.php" class="card">
      <div class="card-icon">🏠</div>
      <div>Beranda Admin</div>
    </a>
  </div>

  <a href="../auth/logout.php" class="logout">🔓 Logout</a>
</div>

</body>
</html>
