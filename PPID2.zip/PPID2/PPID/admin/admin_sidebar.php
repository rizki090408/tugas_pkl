<?php
// Deteksi halaman aktif
$current = basename($_SERVER['PHP_SELF']);

// Base URL (ubah sesuai folder project kamu)
$baseURL = "/PPID2/PPID";
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <h1>📊 PPID Admin</h1>
    </div>
    <nav class="sidebar-nav">
        <a href="<?= $baseURL ?>/admin/dashboard.php" 
           class="nav-item <?= $current == 'dashboard.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-chart-line"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?= $baseURL ?>/admin/detail_permohonan.php" 
           class="nav-item <?= $current == 'detail_permohonan.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-file-alt"></i>
            <span>Data Permohonan</span>
        </a>
        <a href="<?= $baseURL ?>/admin/umpan_balik.php" 
           class="nav-item <?= $current == 'umpan_balik.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-file-invoice"></i>
            <span>Komentar</span>
        </a>
        <a href="<?= $baseURL ?>/auth/logout.php" class="nav-item logout">
            <i class="fa-solid fa-right-from-bracket"></i>
            <span>Logout</span>
        </a>
    </nav>
</aside>

<style>
:root {
    --primary: #2563eb;
    --bg: #f9fafb;
    --text: #1f2937;
    --card: #ffffff;
}

/* Sidebar */
.sidebar {
    width: 240px;
    background: var(--card);
    border-right: 1px solid #e5e7eb;
    box-shadow: 2px 0 10px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    padding: 20px 0;
    position: fixed;
    top: 0;
    left: 0;
    height: 100vh;
}

/* Sidebar header */
.sidebar-header {
    padding: 0 20px;
    margin-bottom: 30px;
    text-align: center;
}
.sidebar-header h1 {
    font-size: 18px;
    font-weight: 700;
    color: var(--primary);
}

/* Nav */
.sidebar-nav {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
.nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 20px;
    color: var(--text);
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    border-left: 3px solid transparent;
    transition: all 0.25s ease;
}
.nav-item i {
    width: 18px;
    text-align: center;
    font-size: 15px;
    color: #6b7280;
    transition: color 0.25s ease;
}
.nav-item:hover {
    background: rgba(37, 99, 235, 0.07);
    border-left: 3px solid var(--primary);
    color: var(--primary);
}
.nav-item:hover i {
    color: var(--primary);
}
.nav-item.active {
    background: rgba(37, 99, 235, 0.12);
    border-left: 3px solid var(--primary);
    color: var(--primary);
    font-weight: 600;
}
.nav-item.active i {
    color: var(--primary);
}

/* Logout */
.logout {
    color: #dc2626;
    margin-top: auto;
}
.logout:hover {
    background: rgba(220, 38, 38, 0.07);
    border-left: 3px solid #dc2626;
    color: #dc2626;
}
.logout i {
    color: #dc2626;
}

/* Konten supaya tidak ketutup sidebar */
main {
    margin-left: 240px; /* sama dengan lebar sidebar */
    padding: 25px;
}

/* Responsive */
@media (max-width: 768px) {
    .sidebar {
        width: 60px;
    }
    main {
        margin-left: 60px;
    }
    .sidebar-header h1,
    .nav-item span {
        display: none;
    }
    .nav-item {
        justify-content: center;
        padding: 12px 0;
    }
}
</style>

<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/your-kit-id.js" crossorigin="anonymous"></script>
