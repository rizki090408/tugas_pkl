<?php
session_start();
include '../includes/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm']);
    $nik      = trim($_POST['nik']);
    $no_hp    = trim($_POST['no_hp']);
    $alamat   = trim($_POST['alamat']);
    $email    = trim($_POST['email']);

    // Validasi password
    if (strlen($password) < 4) {
        echo "<script>alert('Password minimal 4 karakter!');history.go(-1);</script>";
        exit();
    }

    if ($password !== $confirm) {
        echo "<script>alert('Konfirmasi password tidak cocok!');history.go(-1);</script>";
        exit();
    }

    // Validasi NIK
    if (!preg_match('/^[0-9]{16}$/', $nik)) {
        echo "<script>alert('NIK harus 16 digit angka!');history.go(-1);</script>";
        exit();
    }

    // Validasi No HP
    if (!preg_match('/^[0-9]{10,15}$/', $no_hp)) {
        echo "<script>alert('Nomor HP harus 10-15 digit angka!');history.go(-1);</script>";
        exit();
    }

    // Validasi Email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Format email tidak valid!');history.go(-1);</script>";
        exit();
    }

    // Cek username sudah digunakan
    $cek = mysqli_query($koneksi, "SELECT * FROM user WHERE username='$username'");
    if (mysqli_num_rows($cek) > 0) {
        echo "<script>alert('Username sudah digunakan!');history.go(-1);</script>";
        exit();
    }

    // Simpan data
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $role = 'user';

    $simpan = mysqli_query($koneksi, "INSERT INTO user (username, password,  nik, no_hp, alamat, email)
                VALUES ('$username', '$hash',  '$nik', '$no_hp', '$alamat', '$email')");

    if ($simpan) {
        echo "<script>alert('Registrasi berhasil! Silakan login.');window.location.href='login.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan ke database!');history.go(-1);</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Registrasi Akun - PPID BBPMP Jabar</title>
  <link rel="icon" href="../assets/img/bbpmp.png">
   <style>
  * {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #f4f6f9;
  }

  .container {
    display: flex;
    min-height: 100vh;
  }

  .left-side {
    flex: 1;
    background-color: #ffffff;
    color: #1a1a1a;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 40px;
    text-align: center;
  }

  .left-side img {
    width: 200px;
    margin-bottom: 20px;
  }

  .left-side h1 {
    font-size: 36px;
    margin: 0;
  }

  .right-side {
    flex: 2;
    background-color: #000000;
    color: white;
    padding: 60px 40px;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }

  .right-side h2 {
    font-size: 26px;
    margin-bottom: 30px;
    color: #ffffff;
  }

  form {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px 25px;
  }

  .form-group {
    display: flex;
    flex-direction: column;
  }

  .form-group.full {
    grid-column: span 2;
  }

  label {
    margin-bottom: 6px;
    font-weight: 600;
    color: #ffffff;
  }

  input, textarea {
    padding: 10px 12px;
    font-size: 15px;
    border: 1px solid #ccc;
    border-radius: 8px;
    transition: border-color 0.2s;
    background-color: #fff;
    color: #000;
  }

  input:focus, textarea:focus {
    border-color: #003bb9ff;
    outline: none;
  }

  textarea {
    resize: vertical;
  }

  .btn-submit {
    grid-column: span 2;
    background-color: #145eff;
    color: white;
    padding: 12px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
    font-weight: bold;
  }

  .btn-submit:hover {
    background-color: #013cbdff;
  }

  .login-link {
    grid-column: span 2;
    text-align: center;
    font-size: 14px;
    margin-top: 15px;
    color: #fff;
  }

  .login-link a {
    color: #145eff;
    text-decoration: none;
  }

  .login-link a:hover {
    text-decoration: underline;
  }

  @media (max-width: 768px) {
    .container {
      flex-direction: column;
    }
    form {
      grid-template-columns: 1fr;
    }
    .btn-submit, .form-group.full, .login-link {
      grid-column: span 1;
    }
    .right-side {
      padding: 40px 20px;
    }
  }

 
</style>

</head>
<body>

<div class="container">
  <div class="left-side">
    <img  src="../assets/img/bbpmptext.png" alt="Logo BBPMP" />
    <h1><span style="color: #1a32b6">P</span><span style="color: #f0c800">PID</span></h1>
  </div>

  <div class="right-side">
    <h2>Form Registrasi Akun</h2>
    <form method="post">
      <div class="form-group">
        <label for="username">Username</label>
        <input name="username" type="text" id="username" required>
      </div>
      <div class="form-group">
        <label for="nik">NIK</label>
        <input name="nik" type="text" id="nik" required>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input name="password" type="password" id="password" required>
      </div>
      <div class="form-group">
        <label for="confirm">Konfirmasi Password</label>
        <input name="confirm" type="password" id="confirm" required>
      </div>
      <div class="form-group">
        <label for="email">Email Aktif</label>
        <input name="email" type="email" id="email" required>
      </div>
      <div class="form-group">
        <label for="no_hp">No HP</label>
        <input name="no_hp" type="text" id="no_hp" required>
      </div>
      <div class="form-group full">
        <label for="alamat">Alamat Lengkap</label>
        <textarea name="alamat" id="alamat" rows="3" required></textarea>
      </div>
      <button class="btn-submit" type="submit">Daftar Sekarang</button>
      <div class="login-link">
        Sudah punya akun? <a href="login.php">Login di sini</a>
      </div>
    </form>
  </div>
</div>

</body>
</html>
