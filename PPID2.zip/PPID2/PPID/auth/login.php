<?php
session_start();
include '../includes/koneksi.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nik      = trim($_POST['nik']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($nik) || empty($username) || empty($password)) {
        $error = "Semua kolom wajib diisi!";
    } else {
        // Cek berdasarkan nik dan username
        $stmt = mysqli_prepare($koneksi, "SELECT id, nik, username, password, role FROM user WHERE nik = ? AND username = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, "ss", $nik, $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);

            if (password_verify($password, $user['password'])) {
                // Set session
                $_SESSION['user'] = $user;



                // Redirect sesuai role
                if ($user['role'] === 'admin') {
                    header("Location: ../admin/dashboard.php");
                    exit();
                } elseif ($user['role'] === 'user') {
                    header("Location: ../index.php");
                    exit();
                } else {
                    $error = "Role tidak valid.";
                }
            } else {
                $error = "Password salah.";
            }
        } else {
            $error = "NIK atau Username tidak ditemukan.";
        }

        mysqli_stmt_close($stmt);
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Login - PPID BBPMP Jabar</title>
  <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
  <div class="container">
    <div class="left-side">
      <img src="../assets/img/bbpmptext.png" alt="Logo BBPMP">
      <h1><span style="color: #1a32b6">P</span><span style="color: #f0c800">PID</span></h1>
    </div>
    <div class="right-side">
      <h2>Login Akun Anda</h2>

      <?php if (!empty($error)): ?>
        <div style="color: red; margin-bottom: 10px;"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <form method="post">
        <div class="input-group">
          <input type="text" name="nik" placeholder="NIK" required>
          <input type="text" name="username" placeholder="Username" required>
          <input type="password" name="password" placeholder="Password" required>
        </div>
        <div class="options">
          <p>Belum punya akun? <a href="register.php">Daftar sekarang</a></p>
        </div>
        <button type="submit" class="btn-login">Login</button>
      </form>
    </div>
  </div>
</body>
</html>
