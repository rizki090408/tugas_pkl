<?php
session_start();
include 'includes/koneksi.php';

if (!isset($_SESSION['user'])) {
    header("Location: auth/login.php");
    exit();
}

$user = $_SESSION['user'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = trim($_POST['nama']);
    $email = trim($_POST['email']);
    $alamat = trim($_POST['alamat']);

    // Ambil data lama untuk cek foto
    $result = $koneksi->query("SELECT foto FROM user WHERE id=" . intval($user['id']));
    $oldData = $result->fetch_assoc();
    $fotoFile = $oldData['foto'];

    // Jika ada foto baru
    if (!empty($_FILES['foto']['tmp_name'])) {
        $ext = strtolower(pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION));
        $newName = time() . "_" . $user['id'] . "." . $ext;

        // Pindahkan file ke folder upload
        if (move_uploaded_file($_FILES['foto']['tmp_name'], "upload/" . $newName)) {
            // Hapus foto lama jika ada
            if (!empty($fotoFile) && file_exists("upload/" . $fotoFile)) {
                unlink("upload/" . $fotoFile);
            }
            $fotoFile = $newName;
        }
    }

    // Update database
    $stmt = $koneksi->prepare("UPDATE user SET nama=?, email=?, alamat=?, foto=? WHERE id=?");
    $stmt->bind_param("ssssi", $nama, $email, $alamat, $fotoFile, $user['id']);

    if ($stmt->execute()) {
        $result = $koneksi->query("SELECT * FROM user WHERE id=" . intval($user['id']));
        $_SESSION['user'] = $result->fetch_assoc();
        header("Location: detail_profile.php");
        exit();
    } else {
        $error = "Gagal memperbarui profil: " . $stmt->error;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Profil</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {
    font-family: 'Segoe UI', sans-serif;
    background: #f5f6fa;
    margin: 0;
    padding: 40px;
}
.form-container {
    max-width: 500px;
    margin: auto;
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
}
.form-container h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #3f51b5;
}
input[type="text"], input[type="email"], input[type="file"], textarea {
    width: 95%;
    padding: 12px;
    margin: 8px 0;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 0.95rem;
    background: #fafafa;
}
textarea {
    resize: vertical;
    min-height: 70px;
}
button {
    width: 45%;
    background: #3f51b5;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    position: center;
}
button:hover {
    background: #283593;
}
.error {
    color: red;
    text-align: center;
    margin-bottom: 10px;
}
.profile-pic-container {
    position: relative;
    display: inline-block;
}
.profile-pic {
    width: 130px;
    height: 130px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #e0e0e0;
}
.delete-icon {
    position: absolute;
    top: -5px;
    right: -5px;
    background: #d32f2f;
    color: white;
    border-radius: 50%;
    padding: 5px 10px;
    font-size: 14px;
    text-decoration: none;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    height:auto;
}
.delete-icon:hover {
    background: #b71c1c;
}
.profile-wrapper {
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
}
</style>
</head>
<body>

<div class="form-container">
    <h2>Edit Profil</h2>
    <?php if (!empty($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>

    <!-- Foto Profil + Icon Hapus -->
    <div class="profile-wrapper">
        <div class="profile-pic-container">
            <img src="<?= !empty($user['foto']) ? 'upload/' . $user['foto'] : 'default.png' ?>" alt="Foto Profil" class="profile-pic">
            <?php if (!empty($user['foto'])): ?>
                <a href="hapus_foto.php" class="delete-icon" title="Hapus Foto" onclick="return confirm('Yakin hapus foto?')">&#128465;</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Form Edit -->
    <form method="post" enctype="multipart/form-data">
    <input type="text" name="nama" value="<?= htmlspecialchars($user['nama']) ?>" placeholder="Nama Lengkap" required>
    <input type="email" name="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" placeholder="Email">
    <textarea name="alamat" placeholder="Alamat Lengkap"><?= htmlspecialchars($user['alamat'] ?? '') ?></textarea>
    <input type="file" name="foto" accept="image/*">
    
    <div style="display:flex; justify-content:space-between; margin-top:10px;">
        <button type="submit">Simpan</button>
        <button type="button" onclick="history.back();" style="background:#9e9e9e;">Kembali</button>
    </div>
</form>



</body>
</html>
