<?php
include 'includes/header.php';
include 'includes/koneksi.php';
?>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
  body {
    font-family: 'Inter', sans-serif;
    background: #f5f6f8;
    margin: 0;
    padding: 0;
  }

  .main-content {
    margin-top: 100px;
    max-width: 900px;
    margin-left: auto;
    margin-right: auto;
    background: #fff;
    border-radius: 12px;
    padding: 40px 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  }

  h2 {
    margin-bottom: 24px;
    color: #333;
  }

  h3 {
    margin-top: 30px;
    margin-bottom: 20px;
    color: #00796b;
    font-size: 20px;
  }

  form.form-permohonan {
    display: flex;
    flex-direction: column;
  }

  .form-section {
    margin-bottom: 30px;
  }

  label {
    margin-top: 12px;
    font-weight: 500;
    color: #444;
  }

  input[type="text"],
  input[type="email"],
  input[type="file"],
  select,
  textarea {
    width: 100%;
    padding: 10px 12px;
    margin-top: 6px;
    margin-bottom: 14px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    transition: border-color 0.2s;
  }

  input[type="text"]:focus,
  input[type="email"]:focus,
  input[type="file"]:focus,
  select:focus,
  textarea:focus {
    border-color: #009688;
    outline: none;
  }

  textarea {
    min-height: 90px;
    resize: vertical;
  }

  .btn-submit {
    background: #009688;
    color: #fff;
    padding: 12px 20px;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    margin-top: 10px;
    transition: background 0.2s ease;
  }

  .btn-submit:hover {
    background: #00796b;
  }

  @media(max-width:600px) {
    .main-content {
      padding: 20px 15px;
    }
  }
</style>

<div class="main-content">
  <h2>Form Permohonan Informasi</h2>

  <form action="simpan permohonan.php" method="POST" enctype="multipart/form-data" class="form-permohonan">

    <!-- DATA PRIBADI -->
    <div class="form-section">
      <h3>Data Pribadi</h3>

      <label>Nama Lengkap</label>
      <input type="text" name="nama" required>

      <label>Jenis Kelamin</label>
      <select name="jenis_kelamin" required>
        <option value="">-- Pilih --</option>
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
      </select>

      <label>No. HP</label>
      <input type="text" name="no_hp" required>

      <label>No. KTP</label>
      <input type="text" name="ktp" required>

      <label>Alamat E-mail</label>
      <input type="email" name="email" required>

      <label>Pekerjaan</label>
      <input type="text" name="pekerjaan" required>

      <label>Nama Unit Kerja</label>
      <input type="text" name="unit_kerja">

      <label>Alamat</label>
      <textarea name="alamat" required></textarea>

      <label>Kab/Kota</label>
      <input type="text" name="kabkota" required>

      <label>Provinsi</label>
      <input type="text" name="provinsi" required>
    </div>

    <!-- INFORMASI -->
    <div class="form-section">
      <h3>Permohonan Informasi</h3>

      <label>Kategori Informasi yang Dibutuhkan</label>
      <select name="kategori" required>
        <option value="">-- Pilih --</option>
        <option value="Revitalisasi Satdik">Revitalisasi Satdik</option>
        <option value="Digitalisasi Pembelajaran">Digitalisasi Pembelajaran</option>
        <option value="SPMB & Dapodik">SPMB & Dapodik</option>
        <option value="Wajar 13 Th & ATS">Wajar 13 Th & ATS</option>
        <option value="Deep Learning">Deep Learning</option>
        <option value="MBG & Inklusi">MBG & Inklusi</option>
        <option value="7 Kebiasaan Baik">7 Kebiasaan Baik</option>
        <option value="Sekolah Unggulan">Sekolah Unggulan</option>
        <option value="BOSP, PIP & KIP">BOSP, PIP & KIP</option>
        <option value="TPPK & GSS">TPPK & GSS</option>
        <option value="PBD">PBD</option>
        <option value="Lainnya">Lainnya</option>
      </select>

      <label>Fasilitas</label>
      <textarea name="fasilitas"></textarea>

      <label>Rincian Informasi yang Dibutuhkan</label>
      <textarea name="informasi" required></textarea>

      <label>Tujuan Penggunaan Informasi</label>
      <textarea name="tujuan" required></textarea>

      <label>Cara Memperoleh Informasi</label>
      <select name="cara_memperoleh" required>
        <option value="">-- Pilih --</option>
        <option value="Melihat/Mendengar/Mencatat">Melihat/Mendengar/Mencatat</option>
        <option value="Mendapatkan salinan (hardcopy/softcopy)">Mendapatkan salinan (hardcopy/softcopy)</option>
      </select>

      <label>Cara Mendapatkan Salinan</label>
      <select name="cara_salinan" required>
        <option value="">-- Pilih --</option>
        <option value="Ambil Langsung">Ambil Langsung</option>
        <option value="Kurir">Kurir</option>
        <option value="Pos">Pos</option>
        <option value="Faksimili">Faksimili</option>
        <option value="Email">Email</option>
      </select>

      <label>Upload Dokumen Pendukung (PDF/JPG/PNG)</label>
      <input type="file" name="dokumen" accept=".pdf,.jpg,.jpeg,.png">
    </div>

    <button type="submit" class="btn-submit">Kirim Permohonan</button>
  </form>
</div>
